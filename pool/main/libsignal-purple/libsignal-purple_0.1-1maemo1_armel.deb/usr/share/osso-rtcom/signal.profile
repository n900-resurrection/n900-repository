[Profile]
Manager=haze
Protocol=signal
IconName = im-signal
DisplayName=Signal
ConfigurationUI = haze-plugin
Capabilities = chat-p2p, supports-alias, supports-roster
SupportedPresences = away,extended-away,hidden,do-not-disturb


[Presence available]
Name = Online
IconName = general_presence_online
Type = 2

[Presence offline]
Name = Offline
IconName = general_presence_offline
Type = 1

[Presence away]
Name = Away
IconName = general_presence_away
Type = 3

[Presence busy]
Name = Busy
IconName = general_presence_busy
Type = 6

[Presence invisible]
Name = Invisible
IconName = general_presence_invisible
Type = 5

[Presence ext_away]
Name = Extended Away
IconName = general_presence_away
Type = 4

