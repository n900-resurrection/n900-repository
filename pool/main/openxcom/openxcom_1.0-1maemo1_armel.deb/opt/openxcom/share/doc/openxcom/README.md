# OpenXcom for the Nokia N900

[OpenXcom](https://openxcom.org) is an open-source reimplementation of the engine of **UFO: Enemy Unknown** (X-COM, 1994). This package is
**OpenXcom 1.0** (the last release that uses SDL 1.2) built for Maemo 5, with a launcher that sets the game up for the phone.

**The data of the original game is not included and cannot be: you need your own copy of UFO: Enemy Unknown** (the DOS version, for example
the one that DOSBox uses, or the Steam/GOG one). It is not copied or changed; the game reads it where it is.

## Install and start

```bash
apt-get install openxcom      # also needs libsdl-mixer1.2 and libsdl-image1.2 (the phone has them)
```

Copy the folder of the original game (it has `GEODATA`, `MAPS`, `SOUND`, `UFOGRAPH`... in any letter case) to the memory card, for example
`MyDocs/X-Com`, and start **OpenXcom** from the menu. The launcher looks for the game in `MyDocs/UFO`, `MyDocs/X-Com`, `MyDocs/XCOM`,
`MyDocs/Games/...`, then anywhere in `MyDocs` (five levels deep). Another place: write its path to `~/.openxcom/ufo-path` or set `OPENXCOM_UFO`.

The game needs **about 30 seconds** to start (it loads its rulesets and the graphics of the original game); the first start also makes the
data folder `~/.openxcom/data` (links only, a few seconds). The intro plays; tap to skip it.

## Controls

| | |
|---|---|
| Touch screen | the mouse: tap = left click (this is how the whole game is played) |
| Cursor keys | scroll the globe and the map |
| **Ctrl** | **Esc**: the N900 has no Esc key, so Ctrl is "cancel" and also opens the options menu |
| Enter, letters, Backspace | text fields (the name of your base, saved games) |

The other shortcuts of OpenXcom are letters and digits (`i` interceptors, `b` bases, `g` graphs, `u` Ufopaedia, 1 to 6 time speed...), so they are
on the keyboard. Tab (detail level in the Geoscape, next soldier in the battle) is not on the N900 keyboard; change the key in the options of the
game (Options, Controls) or in `~/.openxcom/user/options.cfg` (close the game first: it rewrites the file when it ends).

## What was tested

On **one N900**, with the DOS version of the game: the game starts and shows the menus; the touch screen works as the mouse; the keyboard
works (a name of a new base was typed); the intro plays and the keyboard still works after it; Ctrl cancels a dialog. **Not tested:** a whole
battle (speed on a 600 MHz processor), saving and loading, music and sounds, the other languages, the original game from Steam/GOG, the demo
version of the game. The speed of the Geoscape and of the battles is not measured. The phone has 245 MB of memory: close other applications.

## What went wrong on the way (and how it was solved)

The port was done in one evening, and most of the time went on the things below. They are kept here because the same traps wait for anyone who
brings an SDL 1.2 game to the N900.

1. **C++ for glibc 2.5.** The phone has `libstdc++` 4.2.1, OpenXcom needs C++11. The `libstdc++.a` of the Ubuntu cross compiler (built for
   glibc 2.39 with a 64-bit `time_t`) is linked **statically**, and the symbols that it asks for and glibc 2.5 does not have (`secure_getenv`,
   `getentropy`, `__clock_gettime64`, a 112-byte `struct stat`...) are supplied by a small shim. This is now the
   [maemo-toolchain](https://github.com/n900-resurrection/maemo-toolchain) repository (`maemo-g++`).
2. **`<math.h>` against `<cmath>`.** glibc 2.5 declares `int isnan(double)` globally; the `math.h` of libstdc++ 13 does `using std::isnan` and the
   two collide. The toolchain has its own `cxx-include/math.h`.
3. **Small things of an old SDL:** `SDL_BUTTON_X1/X2` do not exist in SDL 1.2.13 (defined as 6 and 7), and `<algorithm>` has to be included for
   code that relied on an older libstdc++.
4. **Libraries.** SDL, SDL_mixer and SDL_image are the phone's own (their headers come from the source tarballs, the `.so` files were copied from
   the phone once). SDL_gfx 2.0.26 and yaml-cpp 0.6.3 (no Boost) are built statically.
5. **"GEODATA/PALETTES.DAT not found".** OpenXcom 1.0 looks a file up in three ways only: the exact name, the whole path in UPPER case, the whole
   path in lower case. The original game in `MyDocs` is lower case, but the engine's own `MAPS`, `ROUTES` and `TERRAIN` folders are upper case, so
   `TERRAIN/BLANKS.TAB` was found by none of the three. The launcher builds `~/.openxcom/data` as folders of links with upper-case names that
   merge the original files and the engine's.
6. **"Press any key to continue" that never went away.** That error screen waits for a key on the standard input; it only happened because the
   game was started over ssh. From the menu there is no such waiting.
7. **The keyboard did not work at all, the touch screen did.** Two causes, found with a small SDL program that logs every event and with
   `XGetInputFocus`:
   - with a 640x400 window on the 800x480 display SDL cannot change the screen mode, and the window gets no keyboard focus. With the display set to
     800x480 and full screen the focus is there (and the picture is scaled better, which is why this is the default);
   - OpenXcom calls `SDL_WM_GrabInput(captureMouse)` at the start, and with the default "off" SDL does not grab the keyboard of a full-screen window,
     so the keys go to the desktop. `captureMouse: true` fixes it. The log of the game showed no key event at all before that, afterwards all of them.
8. **There is no Esc key** on the N900. OpenXcom uses Esc to cancel dialogs and to open the options; Ctrl (SDL key 306) is set instead.
9. **`options.cfg` is rewritten when the game ends**, also after `kill`: a change made while the game runs is lost (an old process put the intro
   back once). Edit it only when the game is not running.

10. **A crash at the start without any log** when the game is started from a folder that the user cannot read (`su user` from the root shell
   leaves the current folder at `/root`): OpenXcom does not check the result of its look at the current folder. The launcher changes to the home
   folder first. It showed up only in the tests that run over ssh.

## Settings that the launcher writes (only when there is no `options.cfg`)

```yaml
options:
  displayWidth: 800
  displayHeight: 480
  fullscreen: true
  captureMouse: true       # without it the keyboard does nothing
  keyCancel: 306           # Ctrl instead of Esc
  keyGeoOptions: 306
  keyBattleOptions: 306
```

## Build

`make build` (in the Workshop; downloads the sources and the libraries and checks their SHA-256), `make deb`, `make install`. Before the first
build copy the SDL_mixer and SDL_image libraries of a phone (`scp n900:/usr/lib/libSDL_mixer-1.2.so.0.2.4 n900:/usr/lib/libSDL_image-1.2.so.0.1.3
build/deps/sdl-phone/`). `INCR=1 make build` recompiles only the changed sources of `build/openxcom-src` (for experiments).

## Licence

OpenXcom is **GPL-3** (OpenXcom Developers, the unmodified source of the tag v1.0 is compiled by `build.sh`; no patches). SDL_gfx 2.0.26 is
LGPL-2.1 and linked statically: `build.sh` rebuilds it from the original tarball, so the program can be relinked with another version. yaml-cpp is MIT.
The files of this directory (the launcher, the scripts) are MIT licensed like the rest of the repository.
