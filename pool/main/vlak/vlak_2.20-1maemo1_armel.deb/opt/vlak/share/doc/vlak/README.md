# Vlak for the Nokia N900

**Vlak** ("Train") is a Czech game by Miroslav Němeček from 1993 (MS-DOS, 13 kB): drive a train, pick up cars, aeroplanes, diamonds and other
things, each of which becomes a wagon, do not hit a wall or your own wagons, and drive out of the golden gate. 50 scenes, each with a password.
See [Wikipedia](https://cs.wikipedia.org/wiki/Vlak_(po%C4%8D%C3%ADta%C4%8Dov%C3%A1_hra)) and the [home page of the game](https://www.breatharian.eu/sw/vlak/index.html).

This package is the version **2.20** (the C++ source made for the PicoPad handheld) with a thin SDL 1.2 layer (`port/`) in place of the PicoPad
library: the game files (`game.cpp`, `levels.cpp`, `main.cpp`, the tiles and the sounds) are the author's, compiled unchanged.

## Controls

| Action | Keyboard | Touch screen |
|---|---|---|
| Turn the train | arrow keys | tap on the side of the locomotive you want to go to |
| Password of a scene | Enter (then arrows, Enter) | |
| Cancel | Backspace | |
| Let the game solve the scene | Shift, Tab or H | |
| Quit | Esc or Q | |

Any key (or a tap) in the demo starts a game. The password screen has no touch control yet.

## Build

`make build` (in the Workshop, downloads `Vlak220.zip` from the author's site and checks its SHA-256), `make deb`, `make install`.
`VLAK_WINDOW=1` runs in a window instead of full screen; `VLAK_BPP=32` selects the colour depth (for a desktop X server).

## Licence

The author's words on the home page: *"the game is fully freeware and open source – any material listed here (graphics, sounds, source code) may
be used freely for any purpose, including commercial."* The 8x8 font in `vendor/font8x8_basic.h` is public domain (Daniel Hepper, based on the
IBM VGA font). The files in `port/` are MIT licensed like the rest of this repository.
