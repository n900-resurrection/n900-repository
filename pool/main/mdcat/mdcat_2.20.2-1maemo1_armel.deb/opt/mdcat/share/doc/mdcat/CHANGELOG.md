# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/).
This project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

Use `cargo release` to create a new release.

## [Unreleased]

## [2.20.2] – 2026-11-19

### Added
- Detect the Rex terminal (`$TERM_PROGRAM` is `rex`, or `$TERM` is `xterm-rex`) and show images
  inline in it with the kitty graphics protocol, as in Ghostty.
- `text` in the `h1_text` style of `[theme.styles]` sets the marker written before H1 headings,
  like it does for `h2` to `h6` (see [#65](https://github.com/BIRSAx2/mdcat/issues/65)).

### Changed
- Sixel images use a slightly different colour palette, closer to the original image, after the
  update to icy_sixel 0.7.

### Security
- Update `libz-sys` to 1.1.33, for the zlib heap buffer overflow in RUSTSEC-2026-0544.

## [2.20.1] – 2026-11-13

### Fixed
- The x86_64 Linux release binary crashed with `Illegal instruction` on CPUs without AVX. The 2.20.0
  binary was built on Ubuntu 26.04 (the new `ubuntu-latest`), whose compiler emitted AVX
  instructions for the bundled curl. Release binaries are now built on Ubuntu 24.04 again (see
  [#63]).
- The man page in the release archives is now the file `mdcat.1`, not a directory `mdcat.1/` with
  the man page in it, as it was since 2.6.1. Packagers that read `mdcat.1/mdcat.1` from the archive
  need to read `mdcat.1` instead.

## [2.20.0] – 2026-11-10

### Added
- `--stream`/`defaults.stream` in `~/.config/mdcat/config.toml` renders the input block by block
  as it arrives, instead of after reading all of it, e.g. to follow Markdown while a program
  writes it. A block ends at a blank line followed by a line that is not indented, outside of
  fenced code blocks, HTML blocks such as `<pre>` and comments, and frontmatter. Frontmatter is
  stripped, or rendered as a table with `--frontmatter`, as without `--stream`. Reference links
  and footnotes only resolve against definitions in the same block, and otherwise render as
  literal text. `--no-stream`, `--toc`, and `--watch` turn off `defaults.stream`.

### Fixed
- No longer panics on a definition list inside a list item (see [#58]).
- SVG images that name a generic font family (e.g. `sans-serif` or `monospace`) now fall back to
  an installed font instead of rendering their text without a font (see [#60]).

## [2.19.0] – 2026-10-19

### Added
- `--frontmatter`/`defaults.frontmatter` in `~/.config/mdcat/config.toml` renders YAML/TOML
  frontmatter as a `Key`/`Value` table instead of stripping it. Off by default, to avoid silently
  changing existing output. Falls back to stripping, as before, if the frontmatter isn't a flat
  key-value mapping or fails to parse (see [#53]).
- Auto-detect Sixel support on terminals mdcat doesn't otherwise recognize from
  `$TERM`/`$TERM_PROGRAM`, by sending a Primary Device Attributes (DA1) query and checking for
  Sixel graphics (extension `4`) in the response -- the standards-documented way to detect Sixel
  support, rather than relying solely on terminal-identity heuristics. Only runs once at startup,
  for an interactive terminal mdcat couldn't otherwise identify, and only if no `--image-protocol`
  was given (see [#56]).

### Fixed
- SVG images now rasterize at the resolution needed to fill their terminal cell area, instead of
  always at their native size and then (sometimes) blurrily upscaled. A small SVG (e.g. a 24x24
  icon) previously stayed tiny, or lost quality when stretched to fill a row (see [#55]).

## [2.18.0] – 2026-10-01

### Added
- `--emoji`/`defaults.emoji` in `~/.config/mdcat/config.toml` renders GitHub-style emoji
  shortcodes (e.g. `:+1:`) as Unicode emoji, using the same shortcode names GitHub uses. Off by
  default, to avoid silently changing existing output. Shortcodes inside code spans and code
  blocks are left untouched (see [#50]).

### Fixed
- Frontmatter is now also stripped when the file starts with a UTF-8 byte order mark, when
  it uses TOML `+++` delimiters, or when a delimiter line has trailing whitespace (see [#52]).

## [2.17.0] – 2026-09-15

### Added
- Paginating through [lessi](https://github.com/roblillack/lessi) (a `less` replacement that
  understands the kitty/Sixel graphics protocols) keeps normal terminal detection and inline
  images enabled, instead of falling back to plain ANSI formatting like other pagers (see [#48]).

## [2.16.1] – 2026-09-10

### Fixed
- Stop forcing inline images (via an explicit `--image-protocol`/`image_protocol` config) into
  paginated output. Pagers like `less` cannot handle inline image protocols, so forcing them in
  broke scrolling in math-heavy documents rendered with `--paginate` (see [#45]).

## [2.16.0] – 2026-09-07

### Added
- New `--full-width` flag (and `defaults.full_width` in `~/.config/mdcat/config.toml`) to use the
  full terminal width instead of capping output at 80 columns, without having to pass
  `--columns $(tput cols)` (see [#42]).

### Fixed
- Clarify in the docs that `Renderer::text_from_str`/`text_from_read` (and the free
  `text_from_str` function) never render actual images, only alt text, because a Ratatui `Text` is
  plain styled spans that cannot carry image data; `RenderOptions::images` only affects
  `MdcatWidget`/`MdcatWidgetState`, which draw decoded images as overlays on top of the text. This
  was a common source of confusion for callers using `Renderer` directly without the widget (see
  [#36]).
- Fix a panic when a table cell contains a footnote reference (e.g. `2[^1]`). Table cells handle
  inline events directly instead of going through the generic `Inline` state that footnote
  references were only wired up for, so `FootnoteReference` inside a `TableBlock` fell through to
  the "impossible event" panic (see [#43]).

### Changed
- Lower the "Terminal does not support images, rendering image as link" log message from `INFO`
  to `DEBUG`.  This message fires on every image when rendering into Ratatui `Text`, because that
  code path deliberately disables inline image protocols and renders images as overlays instead;
  at `INFO` it drowned out other diagnostics for `ratatui`-based consumers (see [#37]).

[#37]: https://github.com/BIRSAx2/mdcat/issues/37
[#36]: https://github.com/BIRSAx2/mdcat/issues/36
[#42]: https://github.com/BIRSAx2/mdcat/issues/42
[#43]: https://github.com/BIRSAx2/mdcat/issues/43
[#45]: https://github.com/BIRSAx2/mdcat/issues/45
[#48]: https://github.com/BIRSAx2/mdcat/issues/48
[#50]: https://github.com/BIRSAx2/mdcat/issues/50
[#52]: https://github.com/BIRSAx2/mdcat/issues/52
[#53]: https://github.com/BIRSAx2/mdcat/issues/53
[#55]: https://github.com/BIRSAx2/mdcat/issues/55
[#56]: https://github.com/BIRSAx2/mdcat/issues/56
[#58]: https://github.com/BIRSAx2/mdcat/issues/58
[#60]: https://github.com/BIRSAx2/mdcat/issues/60
[#63]: https://github.com/BIRSAx2/mdcat/issues/63

## [2.15.0] – 2026-08-03

### Added
- New `mdpick` entry point (same binary as `mdcat`, invoked under that name):
  fuzzy-finds a Markdown file below a directory with [fzf](https://github.com/junegunn/fzf),
  honouring `.gitignore`, then renders the selection through a pager, like
  `mdless` (GH #21).
- Mermaid diagrams in fenced ` ```mermaid ` code blocks now render as PNG images on terminals
  with an image protocol, or as Unicode diagrams otherwise, via
  [merman](https://github.com/Latias94/merman). A theme's `mermaid` style controls the colour of
  arrows, borders, and text in both the PNG and Unicode rendering, so diagrams match the active
  theme instead of Mermaid's own default (near-black) palette.

### Changed
- Raised the minimum supported Rust version to 1.95, required by `merman`.

## [2.14.0] – 2026-07-27

### Added
- Tables now use true layout: column widths are distributed proportionally
  and shrunk to fit the terminal, with cell content word-wrapped (rather
  than overflowing) across as many lines as needed. Columns are shrunk no
  further than their longest word where space allows, so wrapping a wide
  neighbour column doesn't force an unrelated narrow column to break a
  short word apart.
- `<br>` inside a table cell now starts a new line within that cell, instead
  of being dropped or printed literally (GH #27).

### Fixed
- Inline and display math inside table cells now use the Unicode fallback
  instead of panicking (GH #28).

## [2.13.0] – 2026-07-21

### Added
- Custom heading markers and GFM alert icons/labels via `text` in a
  `[theme.styles]` entry in `~/.config/mdcat/config.toml`: set `h2`-`h6` to
  override the marker written before heading text, or `alert_note`-
  `alert_caution` to override the icon and label written for that alert
  (GH #23).
- `pulldown-cmark-mdcat`: `Theme` gained `h2_marker`-`h6_marker` and
  `alert_note_label`-`alert_caution_label` fields (all public `String`s)
  controlling the text previously hardcoded in the renderer.
- `--toc` prints a numbered table of contents, generated from the document's
  headings and nested by level, before its content. Entries link to
  `FILE#slug` (a GitHub-style anchor) via OSC 8 so that terminals and later
  viewers that resolve such anchors can jump to that heading; on standard
  input entries are plain text, since there's no file to link to.
- `--image-protocol`/`$MDCAT_IMAGE_PROTOCOL`/`defaults.image_protocol` in
  `~/.config/mdcat/config.toml` forces a specific inline image protocol
  (`none`, `iterm2`, `kitty`, or `sixel`), overriding terminal auto-detection.
  Useful inside tmux/screen, where the outer terminal's capabilities usually
  aren't visible to auto-detection. Precedence: `--image-protocol` wins over
  `$MDCAT_IMAGE_PROTOCOL`, which wins over the config default.
- `--tabs`/`defaults.tabs` in `~/.config/mdcat/config.toml` expands literal
  tabs in the input to spaces, using the given tab stop width, before
  parsing. Off by default, so tabs pass through unchanged; without this, a
  tab inside text content throws off line-wrapping and alignment width
  calculations, since terminals render it as jumping to the next tab stop
  rather than occupying a single column.

### Fixed
- Syntax-highlighted fenced code blocks nested inside list items (or other
  indented blocks) lost their indentation on every line after the first,
  because only untagged (non-highlighted) code blocks re-applied indentation
  after each line.
- Inline images (badges, icons) rendered too small on Sixel and iTerm2, only
  filling part of their allotted terminal row, since they were sent at
  native pixel resolution rather than scaled to a whole number of cell
  rows. Sixel images also drifted into a descending staircase when several
  appeared in a row (e.g. consecutive README badges), and iTerm2 never
  applied any explicit sizing at all (GH #22).

## [2.12.0] – 2026-07-17

### Added
- `--smart-punctuation` renders typographic punctuation: straight quotes
  become curly quotes, `--`/`---` become en/em dashes, and `...` becomes an
  ellipsis. Off by default, to avoid silently changing existing output.
- Definition lists (`Term` / `: Description`) are now rendered, with the term
  in bold and its description(s) indented underneath.
- `--list-themes` prints a short sample rendered with every built-in theme,
  to help pick one.
- Configuration file at `~/.config/mdcat/config.toml`: a `[defaults]` table
  sets default values for `--margin`, `--smart-punctuation`, `--columns`,
  `--local`, and `--fail` (the CLI flag always wins when passed); a `[theme]`
  table picks a built-in theme as a starting point (`base`) and overrides
  individual styles on top of it via a `[theme.palette]` of named colors and
  a `[theme.styles]` table, in the same spirit as editor theme files like
  Helix's `theme.toml`.
- `pulldown-cmark-mdcat`: `Theme`'s style fields are now public (previously
  `pub(crate)`), so themes can be fully customised from outside the crate.
  Added `Theme::with_h1` to keep the derived `h1_prefix_style` background in
  sync when changing the H1 style.

## [2.11.1] – 2026-07-16

### Changed
- The two-space left margin added in 2.11.0 is now opt-in via `--margin`,
  and disabled by default. Previously it was always on with no way to turn
  it off, even with `--no-colour` or `--columns 0`.

### Fixed
- `--margin` now reduces the effective render width by 2 columns, so wrapped
  output plus the margin never exceeds `--columns N`. Previously the margin
  was added after wrapping, so the default 80-column setting could produce
  82-column lines.

## [2.11.0] – 2026-07-09

### Added
- `--watch`/`-w` to re-render a file on every save, for a live preview while
  editing. Requires a single file argument and a terminal on standard output;
  not compatible with `--paginate` or reading from standard input.
- Ratatui widget (`MdcatWidget`) for rendering Markdown inside TUI applications,
  with optional image overlays via the Kitty, iTerm2, Sixel, or halfblocks
  protocols, and inline math rendering for terminals that support image output.

### Fixed
- Ratatui: reference links after a Markdown image now show the correct URL.
  Previously the image's OSC 8 link consumed the next link's queue entry,
  shifting all subsequent reference targets by one.
- Ratatui: image overlays inside block quotes and other indented contexts now
  render at the correct column. The indent was computed in bytes rather than
  display-width columns, causing a drift for multi-byte prefix characters.

## [2.10.1] – 2026-07-05

### Fixed
- Render tables nested in list items.

## [2.10.0] – 2026-07-02

### Added
- Eight built-in colour themes selectable with `--theme` or `$MDCAT_THEME`:
  `catppuccin-mocha`, `catppuccin-latte`, `gruvbox-dark`, `gruvbox-light`,
  `dracula`, `nord`, `solarized-dark`, `solarized-light`.
  Each named theme also sets the matching syntax-highlighting theme for code blocks automatically.
- Auto dark/light detection (`--theme auto`, the default) queries the terminal
  via OSC 11 and picks the appropriate built-in theme.
- `$BAT_THEME`, `$BAT_THEME_DARK`, and `$BAT_THEME_LIGHT` are now read to select
  a syntax-highlighting theme for code blocks when using `--theme dark/light/auto`.
  Any theme shipped with [bat] is accepted.
- GFM alerts (`[!NOTE]`, `[!TIP]`, `[!IMPORTANT]`, `[!WARNING]`, `[!CAUTION]`)
  are rendered with a coloured `│` border and a bold icon + label.
- Inline markup in table cells: bold, italic, strikethrough, inline code, links,
  and images now render with their correct styles instead of being stripped.
- Code blocks now use a coloured background that fills to the right edge of the
  block, replacing the old top/bottom delimiter lines.
- Syntax definitions from [bat] (via [two-face]) replace the built-in syntect
  set, adding TOML, TypeScript, Dockerfile, Zig, Nix, and dozens more languages.
- Sixel image protocol support for terminals such as foot and xterm.
- Strip YAML/TOML frontmatter (`---` / `+++` delimited) before rendering.
- `--columns 0` disables line-wrapping entirely.

### Changed
- Each heading level (H2–H6) now has a distinct colour instead of progressively
  dimming a single accent colour.
- H3–H6 heading markers are no longer indented; all headings start flush to the
  left margin.
- Default column width is now 80 (previously the full terminal width).
- ANSI formatting is suppressed when stdout is not a TTY, so piped output is
  clean plain text.

### Removed
- Removed dead Terminology terminal support.

[bat]: https://github.com/sharkdp/bat
[two-face]: https://github.com/CosmicHorrorDev/two-face

## [2.9.1] – 2026-06-20

### Changed
- Update project links.

## [2.9.0] – 2026-06-20

### Added
- Render footnotes.
- Render inline and display math.
  On terminals with the iTerm2 or kitty image protocol mdcat prints PNG math;
  otherwise it uses Unicode substitutions.

### Changed
- Do not enable inline images in VSCode.
- Stop detecting Terminology as a supported terminal.

## [2.8.0] – 2026-06-18

### Changed
- Project is now maintained by [BIRSAx2](https://github.com/BIRSAx2).
- Update all dependencies.

### Fixed
- Fix clippy lints for Rust 1.96.
- Fix broken intra-doc link in resource handler documentation.
- Remove unused `Osc8Links` struct that caused a build error.

### Removed
- Remove `cargo-vet` supply chain auditing from CI.

## [2.7.1] – 2024-12-14

### Removed
- Drop macOS release builds.  Use homebrew to obtain macOS binaries of `mdcat`.
- Remove simplified panic message; `mdcat` now uses the default panic handler.

### Fixed
- Do not crash on inline HTML elements in a table cell (see [GH-310]).

[GH-310]: https://github.com/swsnr/mdcat/pull/310

## [2.7.0] – 2024-11-24

### Changed
- `mdcat` now uses curl for remote resources (see [GH-304]).
  As a result, mdcat now also supports remote images from FTP, and uses standard curl environment variables for proxy configuration.
  - Consequently, `mdcat` now depends on `libcurl`.

### Removed
- The `mdcat-http-reqwest` crate was removed, as consequence of moving to `curl` (see [GH-304]).
  There is no replacement; users of `pulldown-cmark-mdcat` need to impement remote resource support themselves should they require it.
  All versions of this crate on crates.io have been yanked.

[GH-304]: https://github.com/swsnr/mdcat/issues/304

## [2.6.2] – 2024-11-24

### Fixed
- Do not crash when rendering task lists with paragraphs (see [GH-302]).

[GH-302]: https://github.com/swsnr/mdcat/issues/302

## [2.6.1] – 2024-11-13

### Fixed
- Fix release workflow to restore binary assets.

## [2.6.0] – 2024-11-13

### Added
- Add support for images in Ghostty terminal (see [GH-300]).

[GH-300]: https://github.com/swsnr/mdcat/pull/300

### Removed
- Remove a few dependencies: `mime_guess` and `system_proxy` (see [GH-297]).
- mdcat no longer supports building against the `onig` regex library (see [GH-297]).
- mdcat no longer supports a static build against musl (see [GH-297]).

[GH-297]: https://github.com/swsnr/mdcat/pull/297

## [2.5.0] – 2024-09-26

### Changed
- Update to pulldown-cmark 0.12 (see [GH-276]).
  This notably improves whitespace handling for HTML blocks and inline HTML.
- mdcat now treats inline HTML like inline code, just with different styling (see [GH-276]).
  Specifically, mdcat now wraps inline HTML.

[GH-276]: https://github.com/swsnr/mdcat/pull/276

## [2.4.0] – 2024-09-20

### Added
- Add limited support for tables (see [GH-290]).
  Inline markup is stripped from table cells, and text is not wrapped.

### Changed
- Update dependencies.

[GH-290]: https://github.com/swsnr/mdcat/pull/290

## [2.3.1] – 2024-08-04

### Changed
- Release builds no longer use fat LTO, which significantly reduces compilation time.
- Update dependencies.

### Fixed
- mdcat no longer panics on markups in descriptions of rendered images (see [GH-287]).

[GH-287]: https://github.com/swsnr/mdcat/pull/287

## [2.3.0] – 2024-07-28

### Added
- mdcat now includes a `--completions` argument to generate shell completions for all major shells (see [GH-286]).

### Changed
- Update dependencies.

### Removed
- mdcat now longer builds shell completions and man pages during compilation (see [GH-286]).
  - Packagers now need to build the manpage explicitly during packaging.
- Release artifacts no longer contain completions; use `mdcat --completions` to generate them instead (see [GH-286]).

### Fixed
- Restore binary release artifacts (see [GH-284])

[GH-284]: https://github.com/swsnr/mdcat/issues/284
[GH-286]: https://github.com/swsnr/mdcat/pull/286

## [2.2.0] – 2024-07-11

### Changed

- Update a few vulnerable dependencies.
- Update resvg, which among other things enables colored emoji in SVG files (see [GH-283]).

[Gh-283]: https://github.com/swsnr/mdcat/pull/283

## [2.1.2] – 2024-03-11

### Changed

- Update dependencies to address Rust security advisories.

## [2.1.1] – 2024-01-15

### Changed

- Update all dependencies (see [GH-274]).

[GH-274]: https://github.com/swsnr/mdcat/pull/274

## [2.1.0] – 2023-10-16

### Added

- Support images in VSCode integrated terminal, 1.80 or newer (see [GH-266]).

### Changed
- When rendering iTerm2 images append `.png` to the file name reported to the terminal if mdcat rendered an SVG to PNG (see [GH-267]).
  Previously, mdcat retained the original file extension, and would ask iTerm2 to download a PNG image to an `.svg` file.

### Fixed
- Correct some iTerm2 inline image commands to better comply to the specification (see [GH-267]).
- Always terminate OSC commands with ST instead of BEL, as the latter is the legacy form (see [GH-267]).

[GH-266]: https://github.com/swsnr/mdcat/pull/266
[GH-267]: https://github.com/swsnr/mdcat/pull/267

## [2.0.4] – 2023-10-03

### Changed
- Update all dependencies.
- Bump MSRV to 1.72.

## [2.0.3] – 2023-04-24

### Changed
- mdcat now uses the kitty protocol to render images on WezTerm (see [GH-258]).
- mdcat now downscales images to the column limit if rendering with the kitty protocol (see [GH-258]).
    Previously mdcat scaled down to the window size, which looked strange if a given `--columns` was much smaller than the window size.

[GH-258]: https://github.com/swsnr/mdcat/pull/258

## [2.0.2] – 2023-04-19

### Changed

- Update dependencies.

### Fixed

- Fix SVG rendering:
    - Correctly enable SVG rendering and image processing features by default in `mdcat` (see [GH-256]).
    - Ignore `charset` and other mime type parameters when checking for `image/svg+xml` (see [GH-256]).

[GH-256]: https://github.com/swsnr/mdcat/pull/256

## [2.0.1] – 2023-04-16

### Fixed
- Properly reset line wrapping state in list items (see [GH-254]).
- Flush trailing spaces before starting a link to avoid link styling over an initial whitespace (see [GH-255]).

[GH-254]: https://github.com/swsnr/mdcat/pull/254
[GH-255]: https://github.com/swsnr/mdcat/pull/255

## [2.0.0] – 2023-04-15

### Added
- mdcat now fills paragraph text to the column limit, i.e. fills up short lines and wraps long lines (see [GH-4]).
- mdcat now allows to control color and style via a new `theme` field in `pulldown_cmark_mdcat::Settings` of type `pulldown_cmark_mdcat::Theme` (see [GH-48]).
    `pulldown_cmark_mdcat::Theme::default()` provides the standard mdcat 1.x colors and style.
- mdcat now exposes resource handling via the new `pulldown_cmark_mdcat::resources::ResourceUrlHandler` trait (see [GH-247]).
- `pulldown_cmark_mdcat` allows to disable SVG support and thus avoid the `resvg` dependency by disabling the `svg` feature (see [GH-249]).
- `pulldown_cmark_mdcat` allows to disable image processing support and thus avoid the `image` dependency by disabling the `image-processing` feature (see [GH-250]).

### Changed
- Update all dependencies.
- `mdcat::Settings` now holds a reference to a syntax set, so the syntax set can now be shared among multiple different settings.
- Explicitly set minimum rust version in `Cargo.toml`, and document MSRV policy.
- Move all core rendering functions into a new crate `pulldown-cmark-mdcat`; `mdcat` itself only contains the argument parsing and handling now (see [GH-248]).
    If you were using `mdcat` as a library before, you likely want to use `pulldown-cmark-mdcat` now.
- Move HTTP resource handling into new crate `mdcat-http-reqwest`, in order to isolate the rather heavy `reqwest` dependency (see [GH-248]).
- Increase timeouts for HTTP resources to avoid aborting too early.

### Removed
- `mdcat::Settings.resource_access` and the corresponding `ResourceAccess` enum (see [GH-247]).

[GH-4]: https://github.com/swsnr/mdcat/issues/4
[GH-48]: https://github.com/swsnr/mdcat/issues/48
[GH-247]: https://github.com/swsnr/mdcat/pull/247
[GH-248]: https://github.com/swsnr/mdcat/pull/248
[GH-249]: https://github.com/swsnr/mdcat/pull/249
[GH-250]: https://github.com/swsnr/mdcat/pull/250

## [1.1.1] – 2023-03-18

### Fixed
- No longer elide tracing info below warn level in release builds (see [GH-242]).
  This allows downstream consumers to keep tracing info included in their release builds.

[GH-242]: https://github.com/swsnr/mdcat/issues/242

## [1.1.0] – 2023-02-27

### Changed
- Update all dependencies.
  This removes a transitive dependency on a vulnerable version of `remove_dir_all`, see [GHSA-mc8h-8q98-g5hr].
- No longer sniff mime type from contents to identify SVG images.
  Instead rely on the `Content-Type` header for HTTP(S) images and the file extension for local resources (see [GH-239]).
- Render SVG images using the pure Rust `resvg` crate instead of `rsvg-convert`; mdcat no longer requires the latter tool at runtime (see [GH-240]).

### Fixed
- Use `less -r` instead of `less -R` in `mdless` if both `$PAGER` and `$MDCAT_PAGER` are unset (see [GH-238]).
- Time out external resources if no data was read for 100ms. Previously mdcat waited for 1s before timing out (see [GH-241]).

[GH-236]: https://github.com/swsnr/mdcat/pull/236
[GH-238]: https://github.com/swsnr/mdcat/issues/238
[GH-239]: https://github.com/swsnr/mdcat/pull/239
[GH-240]: https://github.com/swsnr/mdcat/pull/240
[GH-241]: https://github.com/swsnr/mdcat/pull/241

[GHSA-mc8h-8q98-g5hr]: https://github.com/advisories/GHSA-mc8h-8q98-g5hr

## [1.0.0] – 2023-01-07

### Added
- Add `--detect-terminal` to print the name of the detected terminal program (see [GH-232]).
- Add `--ansi` to skip terminal detection and use ANSI-formatting only (see [GH-232]).

### Changed

- Replace `ureq` with `reqwest` (see [GH-229]).
    This implies that the default build now creates a binary linked against the system standard SSL library, i.e. openssl under Linux.
    A fully static build now requires `--no-default-features --features static` for `cargo build`.
- Terminal detection always checks `$TERM` first and trusts its value if it denotes a specific terminal emulator (see [GH-232]).
- Update all dependencies.

### Fixed

- Correctly detect kitty started from iTerm (see [GH-230] and [GH-232]).

[GH-229]: https://github.com/swsnr/mdcat/pull/229
[GH-230]: https://github.com/swsnr/mdcat/pull/230
[GH-232]: https://github.com/swsnr/mdcat/pull/232

## [0.30.3] – 2022-12-01

### Fixed
- Fix release workflow to restore release artifacts (see [GH-218]).

[GH-218]: https://github.com/swsnr/mdcat/pull/218

## [0.30.2] – 2022-12-01

### Changed
- Update Github URL to <https://github.com/swsnr/mdcat>.
- Update dependencies.

## [0.30.1] – 2022-11-29

### Fixed
- Fix workflow syntax error to restore release artifacts.

## [0.30.0] – 2022-11-29

### Added
- Generate completions for `mdless` (see [GH-216]).

### Fixed
- Include generated shell completions in release artifacts.
- Fix completions for mdcat (see [GH-214] and [GH-216])

[GH-214]: https://github.com/swsnr/mdcat/issues/214
[GH-216]: https://github.com/swsnr/mdcat/pull/216

## [0.29.0] – 2022-10-21

### Changed
- Move repository back to <https://github.com/swsnr/mdcat>.
- Restore release binaries.
- Update dependencies, in particular clap to 4.0.15.

### Removed
- Support for `tree_magic_mini` for mime-type detection; mdcat now only uses the `file` tool (see [GH-204]).

[GH-204]: https://github.com/swsnr/mdcat/pull/204

## [0.28.0] – 2022-07-31

### Changed
- Update all dependencies, in particular syntect to 5.0.0 and pulldown-cmark to 0.9.2.

## [0.27.1] – 2022-04-17

### Fixed
- Build error on Windows (see [#201]).

[#201]: https://codeberg.org/flausch/mdcat/pulls/201

## [0.27.0] – 2022-04-10

### Added
- Add extensive tracing output, to aid debugging (see [#147]).

### Changed
- mdcat no longer invokes `file` to detect SVG images, but now requires the presence of a system-wide magic database (see [#154]).
  Disable default features to restore the previous behaviour to invoke `file` to detect mimetypes.

### Fixed
- File completion with zsh (see [#198]).

[#147]: https://codeberg.org/flausch/mdcat/issues/147
[#154]: https://codeberg.org/flausch/mdcat/issues/154
[#198]: https://codeberg.org/flausch/mdcat/issues/198

## [0.26.1] – 2022-02-12

### Changed
- Moved repository to <https://codeberg.org/flausch/mdcat>.

## [0.26.0] – 2022-02-12

### Changed
- Always output links as OSC-8 hyperlinks unless `--dump` is given.
  In particular, mdcat now prints hyperlinks if invoked as `mdless` or with `-p`, as recent `less` versions support OCS-8 hyperlinks (see [#191]).

[#191]: https://github.com/swsnr/mdcat/issues/191

### Removed
- mdcat no longer attempts to detect OSC8 link support of the underlying terminal.

## [0.25.1] – 2022-01-17

### Changed
- Update pulldown-cmark to 0.9.1 which fixes a minor parsing issue.

## [0.25.0] – 2021-12-23

### Changed
- Update pulldown-cmark to 0.9.
- Buffer writes to terminal and pager, to reduce the amount of syscalls.

## [0.24.2] – 2021-11-19

### Added
- Support for `$TERM=foot*` (see [#193]).

### Fixed
- Fix compiler error with newer `anyhow` versions (see [#192]).

[#192]: https://github.com/swsnr/mdcat/pull/192
[#193]: https://github.com/swsnr/mdcat/pull/193

## [0.24.1] – 2021-10-30

### Fixed
- Fix semi-broken release.
- Document support for foot in manpage.

## [0.24.0] – 2021-10-30

### Added
- Support for [foot](https://codeberg.org/dnkl/foot/) (see [#190]).

[#190]: https://github.com/swsnr/mdcat/pull/190

## [0.23.2] – 2021-07-18

### Changed
- WezTerm is now detected by `TERM` and `TERM_PROGRAM` environment variables (see [#186]).

[#186]: https://github.com/swsnr/mdcat/pull/186

## [0.23.1] – 2021-07-14

### Changed
- Use `TERM_PROGRAM` for determining WezTerm terminal (see [#185]).

[#185]: https://github.com/swsnr/mdcat/pull/185

## [0.23.0] – 2021-07-04

### Added
- Support for [WezTerm](https://wezfurlong.org/wezterm/) (see [#182]).
- Add PowerShell completions (see [#183] and [#184]).

[#182]: https://github.com/swsnr/mdcat/pull/182
[#183]: https://github.com/swsnr/mdcat/issues/183
[#184]: https://github.com/swsnr/mdcat/pull/184

## [0.22.4] – 2021-04-15

### Changed
- Update dependencies

## [0.22.3] – 2021-02-22
### Added
- Refuse to read more than 100MiB from external resources, e.g. images; mdcat cannot display images of that size reasonably anyway (see [#176]).

### Fixed
- Fix type error on FreeBSD (see [#177]).

[#176]: https://github.com/swsnr/mdcat/pull/176
[#177]: https://github.com/swsnr/mdcat/issues/177

## [0.22.2] – 2021-01-01

### Changed
- Replace `reqwest` with `ureq` to fetch images via HTTP/HTTPS (see [#168] and [#169]);
    the latter has considerably less dependencies and builds faster.
    It also builds statically out of the box, hence the static musl builds no longer require `curl` to fetch images.

### Removed
- The `reqwest` cargo feature (see [#168] and [#169]).

[#168]: https://github.com/swsnr/mdcat/issues/168
[#169]: https://github.com/swsnr/mdcat/pull/169

## [0.22.1] – 2020-10-17

### Fixed

- Include manpage source in Windows packages.
    Currently the manpage doesn't build on Windows CI.

## [0.22.0] – 2020-10-17

### Added
- Enable OSC8 hyperlinks in Kitty (see [#165]).
    Kitty supports hyperlinks since [version 0.19][kitty-0.19], see [Kitty #68].
    Note that `mdcat` *unconditionally* prints hyperlinks if it detects a kitty terminal.
    It makes no attempt to detect whether the Kitty version is compatible or the [`allow_hyperlinks`] setting is enabled.
- `mdcat --version` (but not `mdcat -V`) now informs whether HTTP/HTTPS support is builtin or requires `curl`.
- mdcat now includes a manpage (see [#167]).

### Changed
- `mdcat` now asks the controlling terminal for the terminal size and thus correctly detects the terminal size even if standard input, standard output and standard error are all redirected (see [#166]).
- `mdcat` no longer requires `kitty icat` to detect the size of kitty windows (see [#166]).
    Consequently mdcat can now show images on Kitty terminals even over SSH.
- `mdcat --help` no longer uses colours, and always wraps at 80 characters now.

[kitty-0.19]: https://sw.kovidgoyal.net/kitty/changelog.html#id2
[kitty #68]: https://github.com/kovidgoyal/kitty/issues/68
[`allow_hyperlinks`]: https://sw.kovidgoyal.net/kitty/conf.html?highlight=hyperlinks#opt-kitty.allow_hyperlinks
[#165]: https://github.com/swsnr/mdcat/pull/165
[#166]: https://github.com/swsnr/mdcat/pull/166
[#167]: https://github.com/swsnr/mdcat/pull/167

## [0.21.1] – 2020-09-01

### Fixed
- Update pulldown cmark to correctly ignore footnote refs (see [#155]).

[#155]: https://github.com/swsnr/mdcat/issues/155

## [0.21.0] – 2020-08-12

### Added
- Add `--paginate` flag to paginate the output of mdcat (see [#152]);
  with this flag mdcat sends it output to `less -R` or any alternative pager set in `$MDCAT_PAGER` or `$PAGER`.
  This flag also disables all terminal-specific formatting as the pager likely won't support it.
- Paginate output by default if invoked as `mdless`, that is, if `mdcat` is hard-linked to `mdless`.

### Fixed
- Render email autolinks (i.e. `<hello@example.com>`) as `mailto:` links.

[#152]: https://github.com/swsnr/mdcat/issues/152

## [0.20.0] – 2020-07-05
### Added
- `mdcat::TerminalCapabilities` now exposes constructors for specific terminal emulators.
- Render reference link definitions as inline links if possible (see [#149]).
    This mainly affects image links inside inline links which get rendered as reference links.
- `mdcat::Environment` now contains all environment information required to render properly, namely the local hostname and the base URL.

### Changed
- `mdcat::push_tty` now takes an `mdcat::Environment` instead of `base_dir`.
    `base_dir` is now part of `mdcat::Environment`.
- Image links now use purple foreground text (see [#140] and [#149]).
- Image links render as inline links if the terminal does not support inline images and the image is not inside another link (see [#141]).
- `mdcat::TerminalCapabilities` now uses `Option` to denote missing capabilities.

### Fixed
- Always treat links targets as URLs, never as paths.
- On ITerm2 only use the last segment of image URLs as filename for inline images (see [#149]).
    Previously mdcat used the full URL based on a misunderstanding of the [Inline Images Protocol].

[#140]: https://github.com/swsnr/mdcat/issues/140
[#141]: https://github.com/swsnr/mdcat/issues/141
[#149]: https://github.com/swsnr/mdcat/issues/149
[Inline Images Protocol]: https://iterm2.com/documentation-images.html

## [0.19.0] – 2020-06-19
### Added
- Release packages now include generated shell completions for Bash, Zsh and Fish.

### Changed
- Blockquotes no longer have green foreground text (see [#144]).

[#144]: https://github.com/swsnr/mdcat/issues/144

## [0.18.4] – 2020-06-14
### Fixed
- Fix typo in release workflow.
- Update all dependencies to no longer depend on yanked crate versions.

## [0.18.3] – 2020-06-14
### Fixed
- Properly ignore alt text of inline images (see [#148]).

[#148]: https://github.com/swsnr/mdcat/issues/148

## [0.18.2] – 2020-05-31
### Fixed
- Properly upload binaries for releases.

## [0.18.1] – 2020-05-31
### Fixed
- Fix typo in release workflow.

## [0.18.0] – 2020-05-31
### Added
- Add `mdcat::Error` as type alias to `std::io::Error`.

### Changed
- New simpler rendering algorithm (see #[142]) which solves numerous rendering
  issues (see below).
- Handle internal errors with [anyhow] to add more context to errors (see
  [#139]}.
- `mdcat::push_tty` only fails with `std::io::Error`: `mdcat` never visibly
  fails unless it can’t write output.

### Fixed
- Respect `--local-only` and resource access policy; this got lost in some
  refactoring (see [#146]).
- Consistent margins and newlines around paragraphs, HTML blocks and inside list
  items (see [#142]).
- Correctly indent nested code blocks in lists and block quotes (see [#142]).
- No longer print leading blank lines before lists (see [#142]).
- Correctly indent block quotes (see [#142]).
- Colorize the entire text of links (see [#142]).

[#142]: https://github.com/swsnr/mdcat/issues/142
[#139]: https://github.com/swsnr/mdcat/issues/139
[anyhow]: https://docs.rs/crate/anyhow
[#146]: https://github.com/swsnr/mdcat/issues/146

## [0.17.1] – 2020-05-24
### Fixed
- Correctly scale down large images on [kitty] (see [#124] and [#133] by
  [@fspillner]).

[#124]: https://github.com/swsnr/mdcat/issues/124
[#133]: https://github.com/swsnr/mdcat/pull/133

## [0.17.0] – 2020-05-20
### Changed
- `mdcat` is now distributed under the [MPL 2](http://mozilla.org/MPL/2.0/) license;
  some source files remain Apache 2.0 due to 3rd party rights (see [#138]).

### Fixed
- Do not fail with broken pipe error when rending large images (see [#134] by
  [@fspillner]).

[#134]: https://github.com/swsnr/mdcat/issues/134
[#138]: https://github.com/swsnr/mdcat/issues/138

## [0.16.1] – 2020-05-15
### Changed
- `mdcat::push_tty` now takes a `mdcat::Settings` struct which groups all
  external settings.

### Fixed
- Ignore broken pipes; `mdcat | head` no longer errors when `head` closes stdout
  of mdcat early (see [#136]).

[#136]: https://github.com/swsnr/mdcat/issues/136

## [0.16.0] – 2020-04-11
### Changed
- Upgrade to syntect 4.1 and enable its pure Rust regex backend to simplify
  building (see [#131]).  This crate now builds without Clang which fixes
  Clang-related build issues (see [#90])

[#90]: https://github.com/swsnr/mdcat/issues/90
[#131]: https://github.com/swsnr/mdcat/pull/131

## [0.15.1] – 2020-02-15
### Changed
- Update pulldown-cmark to 0.7.

## [0.15.0] – 2020-01-11
### Added
- Release builds now perform full link-time optimization to create a smaller
  binary.  We do recommend to also `strip` the `mdcat` binary.
- Render SVG images in [kitty] (see [#114]).
- Update to reqwest 0.10.
- Process file list as input (see [#54] and [#115], by [@norman-abramovitz]):
    - Add `--fail` flag to exit on the first error when processing a file list;
      the default behaviour is to continue with the next file in case of error.

### Changed
- Replace `remote_resources` feature with `reqwest` feature to use reqwest for
  retrieving remote resources, and fall back to the `curl` command if `reqwest`
  is disabled.

[#114]: https://github.com/swsnr/mdcat/pull/114
[#115]: https://github.com/swsnr/mdcat/pull/115
[#54]: https://github.com/swsnr/mdcat/issues/54
[@norman-abramovitz]: https://github.com/norman-abramovitz

## [0.14.0] – 2019-12-18
### Added
- Render images in [kitty] (see [#65] and [#104] by [@fspillner]).

### Changed
- Update pulldown-cmark to 0.6 which supports CommonMark 0.29 and improves
  parser speed and correctness.
- Enable SIMD in pulldown-cmark to squeeze out the last bit of performance.
- Remove all features except `remote_resources` to reduce build complexity.

### Removed
- No longer depend on `immeta`.

[kitty]: https://sw.kovidgoyal.net/kitty/
[#65]: https://github.com/swsnr/mdcat/issues/65
[#84]: https://github.com/swsnr/mdcat/issues/84
[#104]: https://github.com/swsnr/mdcat/pull/104
[@fspillner]: https://github.com/fspillner

## [0.13.0] – 2019-03-30
### Added
- Render task lists nicely (see [#72]).
- Render strike-through text (see [#71]).  Some terminals do not support this
  feature, and mdcat does not have a fallback currently (see [#73]).

[#73]: https://github.com/swsnr/mdcat/issues/73
[#72]: https://github.com/swsnr/mdcat/issues/72
[#71]: https://github.com/swsnr/mdcat/issues/71

## [0.12.1] – 2018-12-24
### Fixed
- Do not add newline after inline text with styles disabled (see [#49]).

[#49]: https://github.com/swsnr/mdcat/issues/49

## [0.12.0] – 2018-12-20
### Added
- Add `TerminalCapability` struct as replacement for `mdcat::Terminal` trait to
  remove dynamic dispatch and allow for more accurate and less complicated
  conditional compilation of terminal support for different platforms (see
  [#45]).
- Move to Rust 2018, and raise minimum supported Rust version to 1.31 (see
  [#46]).

### Changed
- Drop support for Rust 1.29 and older.
- Do not test specific Rust on versions on Travis CI any longer; Rust stable
  becomes the lowest supported Rust version.

### Removed
- `mdcat::Terminal` trait and implementations (see [#45]).

### Fixed
- Set hostname to local hostname for inline links to `file://` URLs, which
  should properly resolve `file://` URLs over SSH (see [OSC 8 file URLs],
  [#42] and [#44]).

[OSC 8 file URLs]: https://git.io/vd4ee#file-uris-and-the-hostname
[#42]: https://github.com/swsnr/mdcat/pull/42
[#44]: https://github.com/swsnr/mdcat/pull/44
[#45]: https://github.com/swsnr/mdcat/pull/45
[#46]: https://github.com/swsnr/mdcat/issues/46

## [0.11.0] – 2018-10-25
### Changed
- Always print colours regardless of whether stdout if a tty or not.
- Replace `--colour` option with a `--no-colour` flag to turn off styled output.
- `mdcat::push_tty` no longer takes ownership of the `terminal` argument (see
  [#41]).
- Travis CI builds Windows binaries now.
- Test formatting output.

[#41]: https://github.com/swsnr/mdcat/issues/41

## [0.10.1] – 2018-09-09
### Fixed
- Properly package musl binary on Travis CI; restores Linux binary in releases.

## [0.10.0] – 2018-09-09
### Added
- Support colours on Windows 10 console (see [#36]).
- Support musl target on Linux (see [#37] and [#38]).
- Published Linux binary statically links musl now, and has no runtime
  dependencies (see [#29] and [#38]).

[#29]: https://github.com/swsnr/mdcat/issues/29
[#36]: https://github.com/swsnr/mdcat/pull/36
[#37]: https://github.com/swsnr/mdcat/issues/37
[#38]: https://github.com/swsnr/mdcat/pull/38

## [0.9.2] – 2018-08-26
### Fixed
- Do not falsely ignore deployments from Travis CI for Linux and macOS.

## [0.9.1] – 2018-08-26
### Added
- Publish binaries for Linux, macOS and Windows (see [#28]).

### Fixed
- Correctly build macOS and Linux binaries on Travis CI.

[#28]: https://github.com/swsnr/mdcat/issues/28

## [0.9.0] – 2018-08-26
### Added
- `mdcat` builds on Windows now (see [#33] and [#34]).

### Changed
- Refactor internal terminal representation, replacing the terminal enum with a
  new `Terminal` trait and dynamic dispatch (see [#35]).
- Allow to disable specific terminal backends (see [#35]).
- Update minimum Rust version to 1.27.

[#33]: https://github.com/swsnr/mdcat/pull/33
[#34]: https://github.com/swsnr/mdcat/pull/34
[#35]: https://github.com/swsnr/mdcat/pull/35

## [0.8.0] – 2018-02-15
### Added
- Render SVG images in iTerm2 with `rsvg-convert` (requires `librsvg`).
- Expose `TerminalWrite` in `mdcat` crate (see [#20] by [@Byron]).

[#20]: https://github.com/swsnr/mdcat/pull/20
[@Byron]: https://github.com/Byron

## [0.7.0] – 2018-02-08
### Added
- Show images from HTTP and HTTPS URLs inline in iTerm2.
- Add `--local` flag to render only local images inline; for remote images, eg,
  HTTP URLs, show only the image title and the URL.
- Expose `mdcat` as a library crate (see [#18]), but with no guarantees
  about a stable interface, as `mdcat` stays at version 0.x for now.
- Show `--help` with colours.

### Changed
- Adhere to Semantic Versioning, but stay pre-1.0 so anything still goes.

[#18]: https://github.com/swsnr/mdcat/issues/18

## [0.6.0] – 2018-02-02
### Added
- Show inline images in [Terminology] (see [#16] by [@vinipsmaker]).

[Terminology]: http://terminolo.gy
[#16]: https://github.com/swsnr/mdcat/pull/16
[@vinipsmaker]: https://github.com/vinipsmaker

### Changed
- Improve `--help` output: Hide some redundant options, add a bug reporting URL
  and explain the purpose of `mdcat`.
- Reduce dependencies and thus build time

## [0.5.0] – 2018-01-27
### Added
- Show links inline in iTerm2 and terminals based on VTE 0.50 or newer (see
  [#8], [#14] and [#15]).

[#8]: https://github.com/swsnr/mdcat/issues/8
[#14]: https://github.com/swsnr/mdcat/issues/14
[#15]: https://github.com/swsnr/mdcat/issues/15

### Changed
- Improve `--help` output.

### Fixed
- Remove redundant default value from `--colour` help text (see [#10], by [@wezm]).
- Replace light black with green; the former doesn't work with Solarized Dark.

[#10]: https://github.com/swsnr/mdcat/pull/10
[@wezm]: https://github.com/wezm

## [0.4.0] – 2018-01-21
### Changed
- Use 8-bit ANSI colours for syntax highlighting to fit all kinds of terminal
  colour themes.

### Fixed
- Remove excess space at the end of code blocks

### Removed
- Remove `--light` switch which became redundant due to better syntax
  highlighting.

## [0.3.0] – 2018-01-19
### Added
- Print image links
- Show images inline on iTerm.

### Changed
- Rename to `mdcat`; I have no plans to add paging to this tool.

## [0.2.0] – 2018-01-16
### Added
- Highlight code blocks with Solarized color theme (light or dark).
- Naively show inline and block HTML.
- Set iTerm marks for headings.
- Auto-detect whether mdless can use iTerm2 marks.
- Add `--colour` flag to enable or disable coloured output.

## [0.1.1] – 2018-01-14
### Fixed

- Fix Travis CI badge on crates.io.
- Fix license layout in README.

## [0.1.0] – 2018-01-14
### Added

- Support inline formatting.
- Support headings.
- Support code blocks and block quotes.
- Support ordered and unordered lists, with nest.
- Show links, with references grouped by section.

[Unreleased]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.20.2...HEAD
[2.20.2]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.20.1...mdcat-2.20.2
[2.20.1]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.20.0...mdcat-2.20.1
[2.20.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.19.0...mdcat-2.20.0
[2.19.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.18.0...mdcat-2.19.0
[2.18.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.17.0...mdcat-2.18.0
[2.17.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.16.1...mdcat-2.17.0
[2.16.1]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.16.0...mdcat-2.16.1
[2.16.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.15.0...mdcat-2.16.0
[2.15.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.14.0...mdcat-2.15.0
[2.14.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.13.0...mdcat-2.14.0
[2.13.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.12.0...mdcat-2.13.0
[2.12.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.11.1...mdcat-2.12.0
[2.11.1]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.11.0...mdcat-2.11.1
[2.11.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.10.1...mdcat-2.11.0
[2.10.1]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.10.0...mdcat-2.10.1
[2.10.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.9.1...mdcat-2.10.0
[2.9.1]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.9.0...mdcat-2.9.1
[2.9.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.8.0...mdcat-2.9.0
[2.8.0]: https://github.com/BIRSAx2/mdcat/compare/mdcat-2.7.1...mdcat-2.8.0
[2.7.1]: https://github.com/swsnr/mdcat/compare/mdcat-2.7.0...mdcat-2.7.1
[2.7.0]: https://github.com/swsnr/mdcat/compare/mdcat-2.6.2...mdcat-2.7.0
[2.6.2]: https://github.com/swsnr/mdcat/compare/mdcat-2.6.1...mdcat-2.6.2
[2.6.1]: https://github.com/swsnr/mdcat/compare/mdcat-2.6.0...mdcat-2.6.1
[2.6.0]: https://github.com/swsnr/mdcat/compare/mdcat-2.5.0...mdcat-2.6.0
[2.5.0]: https://github.com/swsnr/mdcat/compare/mdcat-2.4.0...mdcat-2.5.0
[2.4.0]: https://github.com/swsnr/mdcat/compare/mdcat-2.3.1...mdcat-2.4.0
[2.3.1]: https://github.com/swsnr/mdcat/compare/mdcat-2.3.0...mdcat-2.3.1
[2.3.0]: https://github.com/swsnr/mdcat/compare/mdcat-2.2.0...mdcat-2.3.0
[2.2.0]: https://github.com/swsnr/mdcat/compare/mdcat-2.1.2...mdcat-2.2.0
[2.1.2]: https://github.com/swsnr/mdcat/compare/mdcat-2.1.1...mdcat-2.1.2
[2.1.1]: https://github.com/swsnr/mdcat/compare/mdcat-2.1.0...mdcat-2.1.1
[2.1.0]: https://github.com/swsnr/mdcat/compare/mdcat-2.0.4...mdcat-2.1.0
[2.0.4]: https://github.com/swsnr/mdcat/compare/mdcat-2.0.3...mdcat-2.0.4
[2.0.3]: https://github.com/swsnr/mdcat/compare/mdcat-2.0.2...mdcat-2.0.3
[2.0.2]: https://github.com/swsnr/mdcat/compare/mdcat-2.0.1...mdcat-2.0.2
[2.0.1]: https://github.com/swsnr/mdcat/compare/mdcat-2.0.0...mdcat-2.0.1
[2.0.0]: https://github.com/swsnr/mdcat/compare/mdcat-1.1.1...mdcat-2.0.0
[1.1.1]: https://github.com/swsnr/mdcat/compare/mdcat-1.1.0...mdcat-1.1.1
[1.1.0]: https://github.com/swsnr/mdcat/compare/mdcat-1.0.0...mdcat-1.1.0
[1.0.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.30.3...mdcat-1.0.0
[0.30.3]: https://github.com/swsnr/mdcat/compare/mdcat-0.30.2...mdcat-0.30.3
[0.30.2]: https://github.com/swsnr/mdcat/compare/mdcat-0.30.1...mdcat-0.30.2
[0.30.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.30.0...mdcat-0.30.1
[0.30.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.29.0...mdcat-0.30.0
[0.29.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.28.0...mdcat-0.29.0
[0.28.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.27.1...mdcat-0.28.0
[0.27.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.27.0...mdcat-0.27.1
[0.27.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.26.1...mdcat-0.27.0
[0.26.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.26.0...mdcat-0.26.1
[0.26.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.25.1...mdcat-0.26.0
[0.25.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.25.0...mdcat-0.25.1
[0.25.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.24.2...mdcat-0.25.0
[0.24.2]: https://github.com/swsnr/mdcat/compare/mdcat-0.24.1...mdcat-0.24.2
[0.24.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.24.0...mdcat-0.24.1
[0.24.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.23.2...mdcat-0.24.0
[0.23.2]: https://github.com/swsnr/mdcat/compare/mdcat-0.23.1...mdcat-0.23.2
[0.23.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.23.0...mdcat-0.23.1
[0.23.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.22.4...mdcat-0.23.0
[0.22.4]: https://github.com/swsnr/mdcat/compare/mdcat-0.22.3...mdcat-0.22.4
[0.22.3]: https://github.com/swsnr/mdcat/compare/mdcat-0.22.2...mdcat-0.22.3
[0.22.2]: https://github.com/swsnr/mdcat/compare/mdcat-0.22.1...mdcat-0.22.2
[0.22.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.22.0...mdcat-0.22.1
[0.22.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.21.1...mdcat-0.22.0
[0.21.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.21.0...mdcat-0.21.1
[0.21.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.20.0...mdcat-0.21.0
[0.20.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.19.0...mdcat-0.20.0
[0.19.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.18.4...mdcat-0.19.0
[0.18.4]: https://github.com/swsnr/mdcat/compare/mdcat-0.18.3...mdcat-0.18.4
[0.18.3]: https://github.com/swsnr/mdcat/compare/mdcat-0.18.2...mdcat-0.18.3
[0.18.2]: https://github.com/swsnr/mdcat/compare/mdcat-0.18.1...mdcat-0.18.2
[0.18.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.18.0...mdcat-0.18.1
[0.18.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.17.1...mdcat-0.18.0
[0.17.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.17.0...mdcat-0.17.1
[0.17.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.16.1...mdcat-0.17.0
[0.16.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.16.0...mdcat-0.16.1
[0.16.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.15.1...mdcat-0.16.0
[0.15.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.15.0...mdcat-0.15.1
[0.15.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.14.0...mdcat-0.15.0
[0.14.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.13.0...mdcat-0.14.0
[0.13.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.12.1...mdcat-0.13.0
[0.12.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.12.0...mdcat-0.12.1
[0.12.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.11.0...mdcat-0.12.0
[0.11.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.10.1...mdcat-0.11.0
[0.10.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.10.0...mdcat-0.10.1
[0.10.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.9.2...mdcat-0.10.0
[0.9.2]: https://github.com/swsnr/mdcat/compare/mdcat-0.9.1...mdcat-0.9.2
[0.9.1]: https://github.com/swsnr/mdcat/compare/mdcat-0.9.0...mdcat-0.9.1
[0.9.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.8.0...mdcat-0.9.0
[0.8.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.7.0...mdcat-0.8.0
[0.7.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.6.0...mdcat-0.7.0
[0.6.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.5.0...mdcat-0.6.0
[0.5.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.4.0...mdcat-0.5.0
[0.4.0]: https://github.com/swsnr/mdcat/compare/mdcat-0.3.0...mdcat-0.4.0
[0.3.0]: https://github.com/swsnr/mdcat/compare/mdless-0.2.0...mdcat-0.3.0
[0.2.0]: https://github.com/swsnr/mdcat/compare/mdless-0.1.1...mdless-0.2.0
[0.1.1]: https://github.com/swsnr/mdcat/compare/mdless-0.1.0...mdless-0.1.1
[0.1.0]: https://github.com/swsnr/mdcat/releases/tag/mdless-0.1.0
