"""gothi: a Flipper Zero style interface (128x64, one bit, six keys) for the Nokia N900 and for the PC."""
__version__ = "0.12.0"
