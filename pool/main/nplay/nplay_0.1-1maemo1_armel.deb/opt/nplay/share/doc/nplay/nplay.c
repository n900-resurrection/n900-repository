/* nplay: a small video player for the N900. ffmpeg (libav*) decodes, SDL 1.2 shows the picture (the Xv overlay of the phone does the
 * colour conversion and the scaling) and plays the sound. The sound is the master clock; late frames are dropped.
 *
 *   nplay [options] VIDEO [AUDIO]
 *
 * VIDEO and AUDIO may be the same file (the default) or two files: the video sites give the picture and the sound separately (DASH),
 * so nplay plays them together without joining them. Each file is opened twice (once per stream thread), so nothing is shared.
 */
#define _GNU_SOURCE
#include <SDL.h>
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>
#include <libswresample/swresample.h>
#include <libavutil/channel_layout.h>
#include <libavutil/imgutils.h>
#include <libavutil/opt.h>
#include <pthread.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define VQ 4                         /* decoded frames waiting for their time */
#define ARING (48000 * 4 * 2)        /* the audio ring: two seconds of 48 kHz stereo S16 */

static const char *vpath, *apath;
static int opt_noaudio, opt_novideo, opt_verbose, opt_window, opt_fast, opt_bench;
static double opt_start;
static volatile int quitting;

/* ---------- the video side ---------- */
static AVFormatContext *vfc;
static AVCodecContext *vcc;
static int vsi = -1;
static struct SwsContext *sws;
static AVFrame *vq[VQ];
static double vq_pts[VQ];
static int vq_n, vq_head, vdone;
static pthread_mutex_t vm = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t vc = PTHREAD_COND_INITIALIZER;

/* ---------- the audio side ---------- */
static AVFormatContext *afc;
static AVCodecContext *acc;
static int asi = -1;
static SwrContext *swr;
static SDL_AudioSpec aspec;
static unsigned char aring[ARING];
static size_t ar_r, ar_count;
static volatile int adone, apaused = 1;
static double a_base = -1.0;         /* the pts of the first sample played */
static unsigned long long a_consumed; /* bytes handed to the sound card */
static Uint32 a_cb_ticks;             /* when the callback last ran (SDL_GetTicks) */
static pthread_mutex_t am = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t ac = PTHREAD_COND_INITIALIZER;

/* The volume is the one of the phone: the volume that the PulseAudio of the phone keeps for the role of our stream (x-maemo), the same that the
 * volume item of the status menu sets. Up/Down change it with pactl (a short shell command finds our stream by the process id, steps of 3 dB). */
static Uint32 bar_until;                       /* the bar at the bottom is on the screen until this time (SDL_GetTicks) */
static int bar_pct;                            /* what it shows: the volume or the position in the file, in percent */
static int bar_is_volume;

static void sys_volume(int dir)
{
    char cmd[1200], line[64] = "";
    snprintf(cmd, sizeof cmd,
        "out=$(pactl list 2>/dev/null | awk -v p=%d '/^Sink Input #/{idx=substr($3,2); v=\"\"} /^\\tVolume:/{if(v==\"\"){v=$3; gsub(/%%/,\"\",v)}} "
        "/application.process.id = /{q=$3; gsub(/\"/,\"\",q); if(q==p) print idx, v}'); "
        "set -- $out; [ -n \"$1\" ] || exit 1; p=$2; "
        "if [ %d -gt 0 ]; then n=$((p*141/100)); [ $n -le $p ] && n=$((p+2)); [ $n -gt 100 ] && n=100; else n=$((p*100/141)); [ $n -lt 1 ] && n=1; fi; "
        "pactl set-sink-input-mute $1 0 >/dev/null 2>&1; pactl set-sink-input-volume $1 $((n*65536/100)) >/dev/null 2>&1; echo $n",
        (int)getpid(), dir);
    FILE *f = popen(cmd, "r");
    if (!f) return;
    if (fgets(line, sizeof line, f) && atoi(line) > 0) {
        if (opt_verbose > 1) fprintf(stderr, "nplay: volume of the stream now %d %%\n", atoi(line));
        bar_pct = atoi(line); bar_is_volume = 1; bar_until = SDL_GetTicks() + 1500;
    }
    pclose(f);
}

static volatile int quality_level;              /* 0 full quality, 1 no loop filter, 2 also skips frames that no other frame needs (set by the main loop when the picture lags) */
static unsigned long t_copy, t_disp;            /* ms spent copying into the overlay / displaying it */
static int ov_swapuv;                           /* YV12: the planes are Y, V, U */
static volatile int seek_gen;                   /* counts the seeks; the decoding threads notice a change and seek their file */
static volatile double seek_to;                 /* the target of the last seek, in seconds */
static volatile double start_pts;               /* frames and samples before this time are thrown away: the start, or the target of the last seek */
static unsigned long n_corrupt;               /* frames the decoder marked as damaged: not shown (they look green or grey) */
static unsigned long n_shown, n_dropped, n_underrun;
static double max_late;

static void die(const char *what, int err)
{
    char b[128] = "";
    if (err < 0) av_strerror(err, b, sizeof b);
    fprintf(stderr, "nplay: %s%s%s\n", what, *b ? ": " : "", b);
    exit(1);
}

static int open_stream(const char *path, enum AVMediaType type, AVFormatContext **fc, AVCodecContext **cc, int *si)
{
    int r = avformat_open_input(fc, path, NULL, NULL);
    if (r < 0) die(path, r);
    if (avformat_find_stream_info(*fc, NULL) < 0) die("no stream info", 0);
    int i = av_find_best_stream(*fc, type, -1, -1, NULL, 0);
    if (i < 0) return -1;
    AVStream *st = (*fc)->streams[i];
    const AVCodec *c = avcodec_find_decoder(st->codecpar->codec_id);
    if (!c) die("no decoder for the stream", 0);
    *cc = avcodec_alloc_context3(c);
    avcodec_parameters_to_context(*cc, st->codecpar);
    (*cc)->thread_count = 1;                       /* one CPU */
    if (type == AVMEDIA_TYPE_VIDEO) {
        (*cc)->flags2 |= AV_CODEC_FLAG2_FAST;
        if (opt_fast) (*cc)->skip_loop_filter = AVDISCARD_ALL;   /* less work, a little less sharp */
    }
    if ((r = avcodec_open2(*cc, c, NULL)) < 0) die("decoder", r);
    for (unsigned k = 0; k < (*fc)->nb_streams; k++)
        if ((int)k != i) (*fc)->streams[k]->discard = AVDISCARD_ALL;
    *si = i;
    if (opt_start > 0) av_seek_frame(*fc, -1, (int64_t)(opt_start * AV_TIME_BASE), AVSEEK_FLAG_BACKWARD);
    return 0;
}

/* ---------- decoding threads ---------- */
/* returns 1 when the frame is at or after the start/seek target (so the decoder has caught up) */
static int video_push(AVFrame *fr, int gen)
{
    if ((fr->flags & AV_FRAME_FLAG_CORRUPT) || fr->decode_error_flags) { n_corrupt++; return 0; }
    double pts = fr->best_effort_timestamp == AV_NOPTS_VALUE ? 0.0 : fr->best_effort_timestamp * av_q2d(vfc->streams[vsi]->time_base);
    if (pts < start_pts) return 0;                 /* before the requested start or seek target (the keyframe is earlier) */
    AVFrame *c;
    if (fr->format == AV_PIX_FMT_YUV420P || fr->format == AV_PIX_FMT_YUVJ420P) {
        c = av_frame_clone(fr);
    } else {                                       /* 4:2:2, 4:4:4 ...: convert; the overlay wants 4:2:0 */
        c = av_frame_alloc();
        c->format = AV_PIX_FMT_YUV420P; c->width = fr->width; c->height = fr->height;
        av_frame_get_buffer(c, 32);
        sws = sws_getCachedContext(sws, fr->width, fr->height, fr->format, fr->width, fr->height, AV_PIX_FMT_YUV420P, SWS_BILINEAR, NULL, NULL, NULL);
        sws_scale(sws, (const uint8_t * const *)fr->data, fr->linesize, 0, fr->height, c->data, c->linesize);
    }
    pthread_mutex_lock(&vm);
    while (vq_n == VQ && !quitting && seek_gen == gen) pthread_cond_wait(&vc, &vm);
    if (!quitting && seek_gen == gen) {
        int i = (vq_head + vq_n) % VQ;
        vq[i] = c; vq_pts[i] = pts; vq_n++;
        pthread_cond_broadcast(&vc);
    } else av_frame_free(&c);
    pthread_mutex_unlock(&vm);
    return 1;
}

static void *video_thread(void *arg)
{
    /* The sound must never wait for the picture: the decoder runs at a lower priority than the sound thread and the sound server. */
    setpriority(PRIO_PROCESS, (id_t)syscall(SYS_gettid), getenv("NPLAY_NICE") ? atoi(getenv("NPLAY_NICE")) : 10);
    AVPacket *pkt = av_packet_alloc();
    AVFrame *fr = av_frame_alloc();
    int gen = 0, catching_up = opt_start > 0;      /* after a start or a seek the decoder runs from the keyframe: cheaply, until the target */
    (void)arg;
    while (!quitting) {
        if (seek_gen != gen) {                     /* a seek was asked for */
            gen = seek_gen;
            av_seek_frame(vfc, -1, (int64_t)(seek_to * AV_TIME_BASE), AVSEEK_FLAG_BACKWARD);
            avcodec_flush_buffers(vcc);
            catching_up = 1;
        }
        if (av_read_frame(vfc, pkt) < 0) break;
        if (pkt->stream_index == vsi) {
            int q = catching_up ? 2 : quality_level;
            vcc->skip_loop_filter = (q >= 1 || opt_fast) ? AVDISCARD_ALL : AVDISCARD_DEFAULT;
            vcc->skip_frame = q >= 2 ? AVDISCARD_NONREF : AVDISCARD_DEFAULT;
            if (avcodec_send_packet(vcc, pkt) >= 0)
                while (!quitting && seek_gen == gen && avcodec_receive_frame(vcc, fr) == 0) {
                    if (video_push(fr, gen)) catching_up = 0;
                    av_frame_unref(fr);
                }
        }
        av_packet_unref(pkt);
    }
    avcodec_send_packet(vcc, NULL);
    while (!quitting && avcodec_receive_frame(vcc, fr) == 0) { video_push(fr, gen); av_frame_unref(fr); }
    pthread_mutex_lock(&vm);
    vdone = 1;
    pthread_cond_broadcast(&vc);
    pthread_mutex_unlock(&vm);
    return NULL;
}

static int a_gen;                              /* the generation (seek count) that the audio thread is working on */

/* base: the pts of the first sample, taken when the ring is empty after a start or a seek */
static void audio_write(const unsigned char *p, size_t n, int gen, double base)
{
    pthread_mutex_lock(&am);
    if (seek_gen != gen) { pthread_mutex_unlock(&am); return; }
    if (a_base < 0) a_base = base;
    while (n && !quitting) {
        size_t room = ARING - ar_count;
        if (!room) { pthread_cond_wait(&ac, &am); if (seek_gen != gen) break; continue; }
        size_t w = (ar_r + ar_count) % ARING, k = n < room ? n : room;
        if (k > ARING - w) k = ARING - w;
        memcpy(aring + w, p, k);
        ar_count += k; p += k; n -= k;
    }
    pthread_mutex_unlock(&am);
}

static void audio_frame(AVFrame *fr)
{
    double pts = fr->pts == AV_NOPTS_VALUE ? 0.0 : fr->pts * av_q2d(afc->streams[asi]->time_base);
    double from = start_pts;
    int skip = 0;
    if (seek_gen != a_gen) return;
    if (pts + (double)fr->nb_samples / fr->sample_rate < from) return;
    if (pts < from) skip = (int)((from - pts) * aspec.freq);
    int max = (int)av_rescale_rnd(swr_get_delay(swr, fr->sample_rate) + fr->nb_samples, aspec.freq, fr->sample_rate, AV_ROUND_UP) + 64;
    uint8_t *out = av_malloc((size_t)max * 4);
    int n = swr_convert(swr, &out, max, (const uint8_t **)fr->extended_data, fr->nb_samples);
    if (n > skip) audio_write(out + (size_t)skip * 4, (size_t)(n - skip) * 4, a_gen, pts > from ? pts : from);
    av_free(out);
}

static void *audio_thread(void *arg)
{
    AVPacket *pkt = av_packet_alloc();
    AVFrame *fr = av_frame_alloc();
    (void)arg;
    while (!quitting) {
        if (seek_gen != a_gen) {
            a_gen = seek_gen;
            av_seek_frame(afc, -1, (int64_t)(seek_to * AV_TIME_BASE), AVSEEK_FLAG_BACKWARD);
            avcodec_flush_buffers(acc);
            swr_convert(swr, NULL, 0, NULL, 0);        /* drop what the resampler still holds */
        }
        if (av_read_frame(afc, pkt) < 0) break;
        if (pkt->stream_index == asi && avcodec_send_packet(acc, pkt) >= 0)
            while (!quitting && seek_gen == a_gen && avcodec_receive_frame(acc, fr) == 0) { audio_frame(fr); av_frame_unref(fr); }
        av_packet_unref(pkt);
    }
    avcodec_send_packet(acc, NULL);
    while (!quitting && avcodec_receive_frame(acc, fr) == 0) { audio_frame(fr); av_frame_unref(fr); }
    adone = 1;
    return NULL;
}

/* called by SDL in its own thread: fill the buffer of the sound card */
static void audio_cb(void *u, Uint8 *stream, int len)
{
    (void)u;
    memset(stream, 0, len);
    pthread_mutex_lock(&am);
    if (!apaused) {
        size_t k = (size_t)len < ar_count ? (size_t)len : ar_count, first = k < ARING - ar_r ? k : ARING - ar_r;
        memcpy(stream, aring + ar_r, first);
        memcpy(stream + first, aring, k - first);
        ar_r = (ar_r + k) % ARING; ar_count -= k; a_consumed += k; a_cb_ticks = SDL_GetTicks();
        if (k < (size_t)len && !adone) n_underrun++;
        pthread_cond_broadcast(&ac);
    }
    pthread_mutex_unlock(&am);
}

/* ---------- the clock ---------- */
static Uint32 wall0, wall_pause_at, wall_paused_total;
static int have_audio;

static double audio_clock(void)
{
    pthread_mutex_lock(&am);
    double c = a_base + (double)a_consumed / ((double)aspec.freq * 4.0);
    /* The sound card takes the data in blocks (4096 samples = 85 ms), so a_consumed jumps; between two calls the clock goes on by the system time. */
    double step = (double)aspec.samples / aspec.freq, since = (SDL_GetTicks() - a_cb_ticks) / 1000.0;
    int running = !apaused && a_cb_ticks;
    pthread_mutex_unlock(&am);
    if (running) c += since < step ? since : step;
    return c - step;                                /* what is heard now is about one block behind what was handed over */
}

static double now(double first_pts)
{
    if (have_audio && a_base >= 0 && !(adone && ar_count == 0)) return audio_clock();
    return first_pts + (SDL_GetTicks() - wall0 - wall_paused_total) / 1000.0;
}

static void set_paused(int p)
{
    pthread_mutex_lock(&am); apaused = p; pthread_mutex_unlock(&am);
    if (p) wall_pause_at = SDL_GetTicks(); else wall_paused_total += SDL_GetTicks() - wall_pause_at;
}

#define BAR_H 16                               /* the strip at the bottom of the screen kept free for the volume bar */

static void draw_volume_bar(SDL_Surface *screen, int show)
{
    SDL_Rect strip = { 0, (Sint16)(screen->h - BAR_H), (Uint16)screen->w, BAR_H };
    SDL_FillRect(screen, &strip, SDL_MapRGB(screen->format, 0, 0, 0));
    if (show) {
        int total = screen->w / 2, x0 = (screen->w - total) / 2;
        SDL_Rect frame = { (Sint16)(x0 - 2), (Sint16)(screen->h - BAR_H + 2), (Uint16)(total + 4), BAR_H - 4 };
        SDL_Rect fill = { (Sint16)x0, (Sint16)(screen->h - BAR_H + 4), (Uint16)(total * bar_pct / 100), BAR_H - 8 };
        SDL_FillRect(screen, &frame, SDL_MapRGB(screen->format, 90, 90, 90));
        SDL_Rect inner = { (Sint16)x0, (Sint16)(screen->h - BAR_H + 4), (Uint16)total, BAR_H - 8 };
        SDL_FillRect(screen, &inner, SDL_MapRGB(screen->format, 20, 20, 20));
        if (fill.w) SDL_FillRect(screen, &fill, bar_is_volume ? SDL_MapRGB(screen->format, 240, 240, 240) : SDL_MapRGB(screen->format, 90, 170, 255));
    }
    SDL_UpdateRect(screen, strip.x, strip.y, strip.w, strip.h);
}

/* ask both decoding threads to seek: drop what is decoded and queued, the sound starts again when a quarter of a second of the new position is ready */
static void do_seek(double target)
{
    pthread_mutex_lock(&am);
    seek_to = target; start_pts = target;
    seek_gen++;
    ar_r = 0; ar_count = 0; a_consumed = 0; a_base = -1.0; a_cb_ticks = 0; apaused = 1;
    pthread_cond_broadcast(&ac);
    pthread_mutex_unlock(&am);
    pthread_mutex_lock(&vm);
    while (vq_n) { av_frame_free(&vq[vq_head]); vq_head = (vq_head + 1) % VQ; vq_n--; }
    pthread_cond_broadcast(&vc);
    pthread_mutex_unlock(&vm);
}

static void usage(void)
{
    fputs("Usage: nplay [options] VIDEO [AUDIO]\n"
          "  VIDEO, AUDIO   media files (the same file by default; a video site gives the picture and the sound apart)\n"
          "  -n             no sound              -N   no picture (sound only)\n"
          "  -s SECONDS     start at this time    -W   window instead of full screen\n"
          "  -f             faster, less sharp decoding (skips the loop filter)\n"
          "  -b             benchmark: decode everything as fast as possible, show nothing\n"
          "  -v             statistics at the end\n"
          "Keys: Esc or q quits, space pauses, Up/Down change the volume of the phone, Left/Right go 10 s back/forward, PgUp/PgDn 60 s.\n"
          "Touch: the top strip (a fifth of the height): left quarter volume down, second quarter volume up, right quarter quits;\n"
          "       below it: the left third goes 10 s back, the right third 10 s forward, the middle pauses.\n", stderr);
    exit(2);
}

int main(int argc, char **argv)
{
    int c;
    while ((c = getopt(argc, argv, "nNs:Wfbvh")) != -1) {
        switch (c) {
        case 'n': opt_noaudio = 1; break;
        case 'N': opt_novideo = 1; break;
        case 's': opt_start = atof(optarg); break;
        case 'W': opt_window = 1; break;
        case 'f': opt_fast = 1; break;
        case 'b': opt_bench = 1; opt_noaudio = 1; break;
        case 'v': opt_verbose++; break;
        default: usage();
        }
    }
    if (optind >= argc) usage();
    vpath = argv[optind];
    apath = optind + 1 < argc ? argv[optind + 1] : vpath;
    av_log_set_level(opt_verbose ? AV_LOG_WARNING : AV_LOG_ERROR);

    if (!opt_novideo && open_stream(vpath, AVMEDIA_TYPE_VIDEO, &vfc, &vcc, &vsi) < 0) {
        if (opt_verbose) fputs("nplay: no video stream\n", stderr);
        opt_novideo = 1;
    }
    if (!opt_noaudio && open_stream(apath, AVMEDIA_TYPE_AUDIO, &afc, &acc, &asi) < 0) opt_noaudio = 1;
    if (opt_novideo && opt_noaudio && !opt_bench) die("nothing to play", 0);

    setenv("SDL_AUDIODRIVER", "pulse", 0);     /* the ALSA plug-in of SDL uses a third of the CPU on the phone */
    /* The volume of the phone (the volume keys, the volume item of the status menu) is the volume that the PulseAudio of the phone remembers for the
     * role of the stream (x-maemo), and nplay's stream has that role: so the system volume works. The Up/Down keys only fine-tune on top of it.
     * NPLAY_OWN_STREAM=1 gives the stream an identity of its own (100 %, not muted): for a phone whose system volume was left muted or very low. */
    if (getenv("NPLAY_OWN_STREAM")) setenv("PULSE_PROP", "module-stream-restore.id=nplay-stream", 0);
    Uint32 flags = SDL_INIT_TIMER | (opt_bench ? 0 : (opt_novideo ? 0 : SDL_INIT_VIDEO) | (opt_noaudio ? 0 : SDL_INIT_AUDIO));
    if (SDL_Init(flags) < 0) die(SDL_GetError(), 0);

    SDL_Surface *screen = NULL;
    SDL_Overlay *ov = NULL;
    if (!opt_novideo && !opt_bench) {
        screen = SDL_SetVideoMode(800, 480, 0, SDL_SWSURFACE | (opt_window ? 0 : SDL_FULLSCREEN));
        if (!screen) die(SDL_GetError(), 0);
        SDL_ShowCursor(SDL_DISABLE);
        SDL_WM_SetCaption("nplay", "nplay");
        /* prefer a format that the video hardware takes (hw_overlay); NPLAY_FORMAT=yv12|iyuv forces one */
        static const Uint32 fmts[2] = { SDL_YV12_OVERLAY, SDL_IYUV_OVERLAY };
        static const char *names[2] = { "yv12", "iyuv" };
        const char *force = getenv("NPLAY_FORMAT");
        for (int k = 0; k < 2 && !ov; k++) {
            if (force && strcmp(force, names[k])) continue;
            SDL_Overlay *o = SDL_CreateYUVOverlay(vcc->width, vcc->height, fmts[k], screen);
            if (!o) continue;
            if (opt_verbose) fprintf(stderr, "nplay: overlay %s: %s\n", names[k], o->hw_overlay ? "hardware (Xv)" : "software");
            if (o->hw_overlay || k == 1 || force) { ov = o; ov_swapuv = (fmts[k] == SDL_YV12_OVERLAY); }
            else SDL_FreeYUVOverlay(o);
        }
        if (!ov) die("no YUV overlay", 0);
        if (opt_verbose) fprintf(stderr, "nplay: %dx%d, overlay %s\n", vcc->width, vcc->height, ov->hw_overlay ? "in hardware (Xv)" : "in software");
    }
    if (!opt_noaudio) {
        SDL_AudioSpec want;
        memset(&want, 0, sizeof want);
        want.freq = 48000; want.format = AUDIO_S16SYS; want.channels = 2; want.samples = 4096; want.callback = audio_cb;
        if (SDL_OpenAudio(&want, &aspec) < 0 || aspec.channels != 2 || aspec.format != AUDIO_S16SYS) {
            fprintf(stderr, "nplay: no sound (%s)\n", SDL_GetError());
            opt_noaudio = 1;
        } else {
            AVChannelLayout out = AV_CHANNEL_LAYOUT_STEREO;
            if (swr_alloc_set_opts2(&swr, &out, AV_SAMPLE_FMT_S16, aspec.freq, &acc->ch_layout, acc->sample_fmt, acc->sample_rate, 0, NULL) < 0 || swr_init(swr) < 0)
                die("resampler", 0);
        }
    }
    have_audio = !opt_noaudio;

    start_pts = opt_start; seek_to = opt_start;
    pthread_t vt, at;
    if (!opt_novideo) pthread_create(&vt, NULL, video_thread, NULL);
    if (have_audio) pthread_create(&at, NULL, audio_thread, NULL);

    SDL_Rect dst = {0, 0, 0, 0};
    if (screen) {                                   /* fit the picture into the screen, keep the aspect ratio */
        double sc = (double)screen->w / vcc->width, sh = (double)(screen->h - BAR_H) / vcc->height;
        if (sh < sc) sc = sh;
        dst.w = (Uint16)(vcc->width * sc); dst.h = (Uint16)(vcc->height * sc);
        dst.x = (screen->w - dst.w) / 2; dst.y = (screen->h - BAR_H - dst.h) / 2;
    }

    /* the sound starts when a quarter of a second is ready (or all of it, if the sound is shorter) */
    if (have_audio) {
        for (;;) {
            pthread_mutex_lock(&am);
            int ready = ar_count >= (size_t)aspec.freq || adone;
            pthread_mutex_unlock(&am);
            if (ready || quitting) break;
            SDL_Delay(10);
        }
        set_paused(0);
        SDL_PauseAudio(0);
    } else set_paused(0);
    wall0 = SDL_GetTicks(); wall_paused_total = 0;

    double first_pts = opt_start, duration = 0.0;
    int paused = 0, have_first = 0, restarting = 0;
    if (vfc && vfc->duration > 0) duration = vfc->duration / (double)AV_TIME_BASE;
    else if (afc && afc->duration > 0) duration = afc->duration / (double)AV_TIME_BASE;
    /* a seek: not while paused, not at the end; the position is shown for a moment as a bar */
#define SEEK(delta) do { \
        if (!paused && !restarting && !(vfc && vdone) && !(have_audio && adone)) { \
            double tgt = now(first_pts) + (delta); \
            if (duration > 2 && tgt > duration - 2) tgt = duration - 2; \
            if (tgt < 0) tgt = 0; \
            do_seek(tgt); restarting = 1; have_first = 0; first_pts = tgt; wall0 = SDL_GetTicks(); wall_paused_total = 0; \
            if (duration > 0) { bar_pct = (int)(100 * tgt / duration); bar_is_volume = 0; bar_until = SDL_GetTicks() + 1500; } \
        } } while (0)
    Uint32 t_bench = SDL_GetTicks(), dbg_t = 0;
    double test_seek_at = -1, test_seek_by = 0, test_vol_at = -1;
    int test_vol_dir = 0;
    if (getenv("NPLAY_TEST_VOL")) sscanf(getenv("NPLAY_TEST_VOL"), "%lf:%d", &test_vol_at, &test_vol_dir);
    if (getenv("NPLAY_TEST_SEEK")) sscanf(getenv("NPLAY_TEST_SEEK"), "%lf:%lf", &test_seek_at, &test_seek_by);
    while (!quitting) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) quitting = 1;
            else if (e.type == SDL_KEYDOWN) {
                if (opt_verbose > 1) fprintf(stderr, "nplay: key sym=%d scancode=%d name=%s\n", e.key.keysym.sym, e.key.keysym.scancode, SDL_GetKeyName(e.key.keysym.sym));
                if (e.key.keysym.sym == SDLK_ESCAPE || e.key.keysym.sym == SDLK_q) quitting = 1;
                else if (e.key.keysym.sym == SDLK_F7 || e.key.keysym.sym == SDLK_UP || e.key.keysym.sym == SDLK_PLUS || e.key.keysym.sym == SDLK_KP_PLUS) sys_volume(1);
                else if (e.key.keysym.sym == SDLK_F8 || e.key.keysym.sym == SDLK_DOWN || e.key.keysym.sym == SDLK_MINUS || e.key.keysym.sym == SDLK_KP_MINUS) sys_volume(-1);
                else if (e.key.keysym.sym == SDLK_RIGHT) SEEK(10);
                else if (e.key.keysym.sym == SDLK_LEFT) SEEK(-10);
                else if (e.key.keysym.sym == SDLK_PAGEUP) SEEK(60);
                else if (e.key.keysym.sym == SDLK_PAGEDOWN) SEEK(-60);
                else if (e.key.keysym.sym == SDLK_SPACE) { paused = !paused; if (have_audio) SDL_PauseAudio(paused); set_paused(paused); }
            } else if (e.type == SDL_MOUSEBUTTONDOWN && screen) {
                if (e.button.y < screen->h / 5 && e.button.x > screen->w * 3 / 4) quitting = 1;
                else if (e.button.y < screen->h / 5 && e.button.x < screen->w / 4) sys_volume(-1);
                else if (e.button.y < screen->h / 5 && e.button.x < screen->w / 2) sys_volume(1);
                else if (e.button.x < screen->w / 3) SEEK(-10);
                else if (e.button.x > screen->w * 2 / 3) SEEK(10);
                else { paused = !paused; if (have_audio) SDL_PauseAudio(paused); set_paused(paused); }
            }
        }
        if (screen) {                                /* the volume bar: drawn after a change, wiped after 1.5 s */
            static int bar_on;
            if (bar_until && (int)(bar_until - SDL_GetTicks()) > 0) { draw_volume_bar(screen, 1); bar_on = 1; }
            else if (bar_on) { draw_volume_bar(screen, 0); bar_on = 0; bar_until = 0; }
        }
        if (test_seek_at >= 0 && (SDL_GetTicks() - t_bench) / 1000.0 >= test_seek_at) { double d = test_seek_by; test_seek_at = -1; SEEK(d); }   /* NPLAY_TEST_SEEK=SECONDS:DELTA, for the tests */
        if (test_vol_at >= 0 && (SDL_GetTicks() - t_bench) / 1000.0 >= test_vol_at) { test_vol_at = -1; sys_volume(test_vol_dir); }   /* NPLAY_TEST_VOL=SECONDS:DIR, for the tests */
        if (paused) { SDL_Delay(50); continue; }
        if (restarting) {                            /* after a seek the sound starts again when a quarter of a second is ready */
            pthread_mutex_lock(&am);
            int ready = !have_audio || ar_count >= (size_t)aspec.freq || adone;
            if (ready && have_audio) apaused = 0;
            pthread_mutex_unlock(&am);
            if (!ready) { SDL_Delay(5); continue; }
            restarting = 0;
        }

        if (opt_novideo) {                           /* sound only: wait for the end */
            pthread_mutex_lock(&am); int end = adone && ar_count == 0; pthread_mutex_unlock(&am);
            if (end) break;
            SDL_Delay(50);
            continue;
        }

        pthread_mutex_lock(&vm);
        if (vq_n == 0) {
            int end = vdone;
            pthread_mutex_unlock(&vm);
            if (end) break;
            SDL_Delay(2);
            continue;
        }
        AVFrame *f = vq[vq_head];
        double pts = vq_pts[vq_head];
        int more = vq_n > 1;
        pthread_mutex_unlock(&vm);

        if (!have_first) { first_pts = pts; have_first = 1; wall0 = SDL_GetTicks(); wall_paused_total = 0; }
        double diff = opt_bench ? 0.0 : pts - now(first_pts);
        if (opt_verbose > 1 && SDL_GetTicks() - dbg_t >= 1000) {
            dbg_t = SDL_GetTicks();
            fprintf(stderr, "nplay: t=%.1f clock=%.2f frame pts=%.2f queue=%d ring=%zuk shown=%lu dropped=%lu underruns=%lu\n", (dbg_t - t_bench) / 1000.0, now(first_pts), pts, vq_n, ar_count / 1024, n_shown, n_dropped, n_underrun);
        }
        if (diff > 0.004) { SDL_Delay(diff > 0.02 ? 10 : 2); continue; }
        if (!opt_bench) {                            /* the picture lags: make the decoder cheaper; it caught up: go back */
            static Uint32 calm_since;
            double lag = -diff;
            if (lag > 0.50 && quality_level < 2) quality_level = 2;
            else if (lag > 0.20 && quality_level < 1) quality_level = 1;
            if (lag > 0.09) calm_since = SDL_GetTicks();           /* one frame (0.04 s) late is normal */
            else if (quality_level > 0 && SDL_GetTicks() - calm_since > 1500) { quality_level--; calm_since = SDL_GetTicks(); }
        }
        int late_drop = !opt_bench && diff < -0.10 && more;      /* late and there is a newer one: skip it */
        if (!late_drop && ov) {
            Uint32 tt0 = SDL_GetTicks();
            SDL_LockYUVOverlay(ov);
            int w = vcc->width, h = vcc->height;
            for (int y = 0; y < h; y++) memcpy(ov->pixels[0] + (size_t)y * ov->pitches[0], f->data[0] + (size_t)y * f->linesize[0], w);
            for (int y = 0; y < (h + 1) / 2; y++) {
                memcpy(ov->pixels[1] + (size_t)y * ov->pitches[1], f->data[ov_swapuv ? 2 : 1] + (size_t)y * f->linesize[ov_swapuv ? 2 : 1], (w + 1) / 2);
                memcpy(ov->pixels[2] + (size_t)y * ov->pitches[2], f->data[ov_swapuv ? 1 : 2] + (size_t)y * f->linesize[ov_swapuv ? 1 : 2], (w + 1) / 2);
            }
            SDL_UnlockYUVOverlay(ov);
            Uint32 tt1 = SDL_GetTicks();
            SDL_DisplayYUVOverlay(ov, &dst);
            t_copy += tt1 - tt0; t_disp += SDL_GetTicks() - tt1;
        }
        if (late_drop) n_dropped++; else { n_shown++; if (-diff > max_late) max_late = -diff; }
        pthread_mutex_lock(&vm);
        av_frame_free(&vq[vq_head]);
        vq_head = (vq_head + 1) % VQ; vq_n--;
        pthread_cond_broadcast(&vc);
        pthread_mutex_unlock(&vm);
    }

    quitting = 1;
    pthread_mutex_lock(&vm); pthread_cond_broadcast(&vc); pthread_mutex_unlock(&vm);
    pthread_mutex_lock(&am); pthread_cond_broadcast(&ac); pthread_mutex_unlock(&am);
    if (opt_verbose || opt_bench) {
        double secs = (SDL_GetTicks() - t_bench) / 1000.0;
        fprintf(stderr, "nplay: %lu frames shown, %lu dropped, %lu audio underruns, worst lateness %.3f s, quality level %d, %lu damaged frames skipped, copy %.1f ms, display %.1f ms per frame", n_shown, n_dropped, n_underrun, max_late, quality_level, n_corrupt, n_shown ? (double)t_copy / n_shown : 0.0, n_shown ? (double)t_disp / n_shown : 0.0);
        if (opt_bench) fprintf(stderr, ", %.1f frames/s", secs > 0 ? n_shown / secs : 0.0);
        fputc('\n', stderr);
    }
    _exit(0);                                        /* the decoding threads may sit in read(); do not wait for them */
}
