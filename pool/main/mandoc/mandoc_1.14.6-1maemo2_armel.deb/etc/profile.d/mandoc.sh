# man pages of the packages in /opt/<package>/share/man (see the package mandoc)
_mp=/usr/share/man
for _d in /opt/*/share/man; do [ -d "$_d" ] && _mp="$_mp:$_d"; done
export MANPATH="$_mp"
export MANPAGER=/opt/mandoc/bin/man-pager
unset _mp _d
# A login shell has /usr/local/bin at the END of the PATH (see /etc/profile.d/sbin-path.sh), so the BusyBox `man` of /usr/bin would win: put ours first.
case ":$PATH:" in *:/opt/mandoc/bin:*) ;; *) PATH="/opt/mandoc/bin:$PATH"; export PATH ;; esac
