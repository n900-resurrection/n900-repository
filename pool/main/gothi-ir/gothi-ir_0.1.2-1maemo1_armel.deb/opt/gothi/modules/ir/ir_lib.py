"""Flipper `.ir` files and the encoding of their buttons into pulses for the IR transmitter.

The file format (https://developer.flipper.net/flipperzero/doxygen/infrared_file_format.html): a header (`Filetype: IR signals file` or
`IR library file`, `Version: 1`) and buttons separated by lines that start with `#`:

    name: Power
    type: parsed                   type: raw
    protocol: Samsung32            frequency: 38000
    address: 07 00 00 00           duty_cycle: 0.330000
    command: 02 00 00 00           data: 4500 4500 550 ...        (microseconds, mark first, at most 1024 values)

address and command are four bytes, the least significant first. The timings of the protocols are those of the Flipper firmware
(lib/infrared/encoder_decoder); the bits go out least significant bit first, except RC5 (the standard order).
No hardware is needed here: `encode()` returns what the driver will be given."""
import re

NEC_TIMING = ((9000, 4500), (560, 1690), (560, 560), 560)               # preamble (mark, space), bit 1, bit 0, stop mark
SAMSUNG_TIMING = ((4500, 4500), (550, 1650), (550, 550), 550)
SIRC_TIMING = ((2400, 600), (1200, 600), (600, 600), None)              # no stop mark: the frame ends with the last bit
RC5_HALF = 888                                                          # microseconds, half of a bit
MAX_WRITE = 255                                                         # the driver takes at most 256 values; an odd number: mark ... mark


class Unsupported(Exception):
    """A protocol that this module cannot encode."""


class Button:
    def __init__(self, name, kind, protocol=None, address=0, command=0, frequency=38000, duty=0.33, data=None):
        self.name, self.kind, self.protocol = name, kind, protocol
        self.address, self.command, self.frequency, self.duty, self.data = address, command, frequency, duty, data or []

    def __repr__(self):
        return f"Button({self.name!r}, {self.kind}, {self.protocol})"


class Plan:
    """What to send: the carrier (Hz), the duty cycle (percent), the timings of one frame (mark first, ends with a mark), how many frames and the
    time from the start of a frame to the start of the next one."""

    def __init__(self, carrier, duty, timings, repeats=1, period=0):
        self.carrier, self.duty, self.timings, self.repeats, self.period = carrier, duty, timings, repeats, period


def hex_le(text):
    """'07 00 00 00' -> 7 (four bytes, the least significant first)."""
    return int.from_bytes(bytes(int(x, 16) for x in text.split()), "little")


def to_hex_le(value, n=4):
    return " ".join(f"{b:02X}" for b in value.to_bytes(n, "little"))


def parse(text):
    """(buttons, errors): the buttons of a `.ir` file; a broken button is skipped and reported, the rest is kept."""
    buttons, errors, cur = [], [], {}

    def close():
        if not cur:
            return
        try:
            buttons.append(_button(cur))
        except (KeyError, ValueError) as e:
            errors.append(f"{cur.get('name', '?')}: {e}")
        cur.clear()

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            close()
            continue
        key, sep, value = line.partition(":")
        if not sep:
            continue
        key, value = key.strip().lower(), value.strip()
        if key == "name":
            close()                                               # a file without "#" lines between the buttons still works
        if key in ("name", "type", "protocol", "address", "command", "frequency", "duty_cycle", "data"):
            cur[key] = value
    close()
    return buttons, errors


def _button(d):
    name, kind = d["name"], d["type"].lower()
    if kind == "parsed":
        return Button(name, "parsed", d["protocol"], hex_le(d["address"]), hex_le(d["command"]))
    if kind == "raw":
        data = [int(x) for x in d["data"].split()]
        if not data or any(x <= 0 for x in data):
            raise ValueError("bad raw data")
        return Button(name, "raw", None, 0, 0, int(d.get("frequency", 38000)), float(d.get("duty_cycle", 0.33)), data)
    raise ValueError(f"unknown type {kind!r}")


def dump(buttons, kind="IR signals file"):
    """The text of a `.ir` file (for the remotes that a learning receiver will bring)."""
    out = [f"Filetype: {kind}", "Version: 1"]
    for b in buttons:
        out += ["#", f"name: {b.name}", f"type: {b.kind}"]
        if b.kind == "parsed":
            out += [f"protocol: {b.protocol}", f"address: {to_hex_le(b.address)}", f"command: {to_hex_le(b.command)}"]
        else:
            out += [f"frequency: {b.frequency}", f"duty_cycle: {b.duty:.6f}", "data: " + " ".join(str(x) for x in b.data)]
    return "\n".join(out) + "\n"


def _pwm(value, nbits, timing):
    """Preamble, the bits least significant first (mark, space), the stop mark."""
    (pm, ps), (b1m, b1s), (b0m, b0s), stop = timing
    t = [pm, ps]
    for i in range(nbits):
        t += [b1m, b1s] if (value >> i) & 1 else [b0m, b0s]
    if stop is not None:
        t.append(stop)
    else:
        t.pop()                                                   # the last space is the silence after the frame
    return t


def _rc5(address, command):
    bits = [1, 1, 0] + [(address >> i) & 1 for i in range(4, -1, -1)] + [(command >> i) & 1 for i in range(5, -1, -1)]
    halves = []
    for b in bits:                                                # 1 = space then mark, 0 = mark then space (Manchester)
        halves += [0, 1] if b else [1, 0]
    runs = []
    for h in halves:
        if runs and runs[-1][0] == h:
            runs[-1][1] += RC5_HALF
        else:
            runs.append([h, RC5_HALF])
    if runs[0][0] == 0:
        runs.pop(0)                                               # the idle space before the first mark is not sent
    if runs[-1][0] == 0:
        runs.pop()                                                # nor the space after the last one
    return [d for _, d in runs]


def encode(b):
    """The Plan for a Button; raises Unsupported."""
    if b.kind == "raw":
        data = list(b.data)
        if len(data) % 2 == 0:
            data.pop()                                            # raw data of the Flipper ends with a space: the driver wants a mark last
        if len(data) > MAX_WRITE:
            raise Unsupported("raw signal too long")
        return Plan(b.frequency, max(1, min(99, round(b.duty * 100))), data)
    p, a, c = b.protocol, b.address, b.command
    if p == "NEC":
        v = (a & 0xFF) | ((~a & 0xFF) << 8) | ((c & 0xFF) << 16) | ((~c & 0xFF) << 24)
        return Plan(38000, 33, _pwm(v, 32, NEC_TIMING))
    if p == "NECext":
        return Plan(38000, 33, _pwm((a & 0xFFFF) | ((c & 0xFFFF) << 16), 32, NEC_TIMING))
    if p == "NEC42":
        d1 = (a & 0x1FFF) | ((~a & 0x1FFF) << 13) | ((c & 0x3F) << 26)
        d2 = ((c & 0xC0) >> 6) | ((~c & 0xFF) << 2)
        return Plan(38000, 33, _pwm(d1 | (d2 << 32), 42, NEC_TIMING))
    if p == "NEC42ext":
        d1 = (a & 0x3FFFFFF) | ((c & 0x3F) << 26)
        d2 = (c & 0xFFC0) >> 6
        return Plan(38000, 33, _pwm(d1 | (d2 << 32), 42, NEC_TIMING))
    if p == "Samsung32":
        v = (a & 0xFF) | ((a & 0xFF) << 8) | ((c & 0xFF) << 16) | ((~c & 0xFF) << 24)
        return Plan(38000, 33, _pwm(v, 32, SAMSUNG_TIMING))
    if p in ("SIRC", "SIRC15", "SIRC20"):
        n, alen = {"SIRC": (12, 5), "SIRC15": (15, 8), "SIRC20": (20, 13)}[p]
        v = (c & 0x7F) | ((a & ((1 << alen) - 1)) << 7)
        return Plan(40000, 33, _pwm(v, n, SIRC_TIMING), repeats=3, period=45000)       # a Sony remote sends the frame three times
    if p == "RC5":
        return Plan(36000, 33, _rc5(a & 0x1F, c & 0x3F))
    raise Unsupported(f"{p}: not supported yet")
