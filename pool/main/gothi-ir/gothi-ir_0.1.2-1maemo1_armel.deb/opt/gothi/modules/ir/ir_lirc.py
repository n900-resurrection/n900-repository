"""The IR transmitter of the N900 (the kernel driver lirc_rx51, the device /dev/lirc0).

The driver is not loaded at boot. pierogi has the two scripts that load and unload it, and the sudoers rule that lets the user run them without
a password. The device belongs to root:video, the user is in `video`. To send: set the carrier and the duty cycle with ioctl, then write the timings
in microseconds as 32-bit numbers (mark, space, mark, ... ending with a mark, an odd number of them, at most 256 per write). A write returns when the
frame has been sent."""
import fcntl
import os
import struct
import subprocess
import threading
import time

DEVICE = "/dev/lirc0"
LOADER = "/opt/pierogi/bin/loadRX51Module"
UNLOADER = "/opt/pierogi/bin/unloadRX51Module"
LIRC_GET_FEATURES = 0x80046900          # _IOR('i', 0x00, __u32)
LIRC_SET_SEND_CARRIER = 0x40046913      # _IOW('i', 0x13, __u32)
LIRC_SET_SEND_DUTY_CYCLE = 0x40046915   # _IOW('i', 0x15, __u32)
LIRC_CAN_SEND_PULSE = 0x00000002


class IrError(Exception):
    pass


class Transmitter:
    def __init__(self, device=DEVICE, loader=LOADER, unloader=UNLOADER, ioctl=fcntl.ioctl, sudo="sudo", wait=5.0, sleep=time.sleep):
        self.device, self.loader, self.unloader, self.ioctl, self.sudo, self.wait, self.sleep = device, loader, unloader, ioctl, sudo, wait, sleep
        self.fd = None
        self.loaded_by_us = False
        self.lock = threading.Lock()

    def _load(self):
        if os.path.exists(self.device) or not self.loader:
            return
        try:
            subprocess.run([self.sudo, self.loader], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20, check=True)
        except (OSError, subprocess.SubprocessError) as e:
            raise IrError("cannot load the IR driver") from e
        self.loaded_by_us = True
        t0 = time.time()
        while not os.path.exists(self.device):                      # the device node appears a moment after the driver
            if time.time() - t0 > self.wait:
                raise IrError("no /dev/lirc0")
            self.sleep(0.1)

    def open(self):
        if self.fd is not None:
            return
        self._load()
        try:
            fd = os.open(self.device, os.O_WRONLY)
        except OSError as e:
            raise IrError(f"cannot open the IR device ({e.strerror})") from e
        try:
            buf = bytearray(4)
            self.ioctl(fd, LIRC_GET_FEATURES, buf)
            can_send = struct.unpack("I", bytes(buf))[0] & LIRC_CAN_SEND_PULSE
        except OSError:
            can_send = True                                         # a plain file in the tests; a real device answers
        if not can_send:
            os.close(fd)
            raise IrError("the device cannot send")
        self.fd = fd

    def send(self, plan):
        """Send a Plan (see ir_lib): the carrier, the duty cycle, the frame `repeats` times, `period` microseconds from start to start."""
        with self.lock:
            self.open()
            try:
                self.ioctl(self.fd, LIRC_SET_SEND_CARRIER, struct.pack("I", int(plan.carrier)))
                self.ioctl(self.fd, LIRC_SET_SEND_DUTY_CYCLE, struct.pack("I", int(plan.duty)))
            except OSError as e:
                raise IrError(f"cannot set the carrier ({e.strerror})") from e
            n = len(plan.timings)
            if n % 2 == 0 or n > 255:
                raise IrError("bad length of the signal")
            data = struct.pack(f"{n}I", *plan.timings)
            frame_us = sum(plan.timings)
            for i in range(max(1, plan.repeats)):
                t0 = time.time()
                try:
                    os.write(self.fd, data)
                except OSError as e:
                    raise IrError(f"write failed ({e.strerror})") from e
                if i + 1 < plan.repeats and plan.period > frame_us:
                    self.sleep(max(0.0, plan.period / 1e6 - (time.time() - t0)))

    def close(self):
        """Close the device and unload the driver again if we loaded it."""
        with self.lock:
            if self.fd is not None:
                try:
                    os.close(self.fd)
                except OSError:
                    pass
                self.fd = None
            if self.loaded_by_us and self.unloader:
                try:
                    subprocess.run([self.sudo, self.unloader], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
                except (OSError, subprocess.SubprocessError):
                    pass
                self.loaded_by_us = False
