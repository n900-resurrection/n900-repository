"""Infrared remotes for gothi: a list of remotes (Flipper `.ir` files), a list of their buttons, OK sends the button.

Where the files are (looked at every time the module is opened, so a new file needs no restart; the same relative name in a later folder wins):
  1. /opt/gothi/ir                 remotes that come in packages (samples)
  2. ~/MyDocs/gothi/ir             yours: copy files there from a computer (USB mass storage, or the file server module), subfolders are fine
  3. ~/.config/gothi/ir            yours, hidden
GOTHI_IR (folders separated by colons) replaces the three, for tests. The N900 can only send: the files come from a Flipper, from a collection
of them or from a receiver that learns."""
import os
import struct
import threading
import time

from gothi import keys
from gothi.apps import Message
from gothi.ui import Menu

import ir_lib
import ir_lirc
import slots
from remote import Buttons, Remote  # noqa: F401  (Buttons: the page More, and the tests)

MAX_DEPTH = 3


def search_dirs():
    env = os.environ.get("GOTHI_IR")
    if env is not None:
        return [d for d in env.split(":") if d]
    home = os.path.expanduser("~")
    return ["/opt/gothi/ir", os.path.join(home, "MyDocs", "gothi", "ir"), os.path.join(home, ".config", "gothi", "ir")]


def find_remotes(dirs=None):
    """{name: path}: the `.ir` files of the folders, the name is the path below the folder without `.ir` (Brand/Model)."""
    found = {}
    for base in (search_dirs() if dirs is None else dirs):
        for root, subdirs, files in os.walk(base):
            depth = os.path.relpath(root, base).count(os.sep) + (0 if root == base else 1)
            if depth >= MAX_DEPTH:
                subdirs[:] = []
            subdirs.sort()
            for f in sorted(files):
                if f.lower().endswith(".ir"):
                    rel = os.path.relpath(os.path.join(root, f), base)[:-3]
                    found[rel.replace(os.sep, "/")] = os.path.join(root, f)
    return dict(sorted(found.items(), key=lambda kv: kv[0].lower()))


def _thread(fn):
    threading.Thread(target=fn, daemon=True).start()


class Remotes(Menu):
    """The list of remotes; the driver is unloaded again when the list is left."""

    def __init__(self, remotes, tx):
        self.paths, self.tx = remotes, tx
        super().__init__("Infrared", [(name, (lambda g, n=name: self.open(n))) for name in remotes])

    def open(self, name):
        try:
            with open(self.paths[name], encoding="utf-8", errors="replace") as f:
                buttons, errors = ir_lib.parse(f.read())
        except OSError as e:
            return Message(name[:20], ["cannot read the file", str(e.strerror)[:24]])
        if not buttons:
            return Message(name[:20], ["no buttons found"] + [e[:24] for e in errors[:3]])
        return Remote(name, buttons, self.tx, forced=slots.load_forced(self.paths[name]))

    def on_exit(self, gothi):
        _thread(self.tx.close)


def create(module):
    remotes = find_remotes()
    if not remotes:
        return Message("Infrared", ["no remotes yet. Put", "Flipper .ir files in", "MyDocs/gothi/ir", "and open this again"])
    dev = os.environ.get("GOTHI_IR_DEVICE")                    # development: a file instead of /dev/lirc0 (nothing is loaded or sent)
    if dev:
        def fake_ioctl(fd, req, arg):
            if isinstance(arg, bytearray):
                arg[:] = struct.pack("I", 0x302)                    # the features of the real device: it can send pulses
        return Remotes(remotes, ir_lirc.Transmitter(device=dev, loader=None, unloader=None, ioctl=fake_ioctl))
    return Remotes(remotes, ir_lirc.Transmitter())
