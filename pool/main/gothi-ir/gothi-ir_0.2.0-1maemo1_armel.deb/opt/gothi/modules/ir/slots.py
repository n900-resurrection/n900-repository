"""Which button of a remote goes to which key of the remote page (a slot), and which key of the phone sends what.

The buttons of the `.ir` files of the Flipper collections have names that repeat from brand to brand (Power, Vol_up, Ok, Return, Num_1, ...), so the
slots are found by name: lower case, without spaces, `_` and `-`, the first name of the list that exists wins. What is not matched stays in `rest`
(the page "More"). A small file next to the remote (`Name.layout.json`, `{"PWR": "Standby"}`) forces a slot to a button by its exact name."""
import json
import os
import re

SLOTS = ["PWR", "SRC", "UP", "DOWN", "LEFT", "RIGHT", "OK", "BACK", "HOME", "MENU", "V+", "V-", "MUTE", "C+", "C-", "LAST",
         "REW", "PLAY", "PAUSE", "STOP", "FWD"] + [str(n) for n in range(10)]

NAMES = {
    "PWR": ["power", "powertoggle", "pwr", "onoff", "poweronoff", "standby"],
    "SRC": ["source", "input", "inputselect", "tvav", "av", "sources"],
    "UP": ["up", "arrowup", "cursorup", "navup", "dpadup"],
    "DOWN": ["down", "arrowdown", "cursordown", "navdown", "dpaddown"],
    "LEFT": ["left", "arrowleft", "cursorleft", "navleft", "dpadleft"],
    "RIGHT": ["right", "arrowright", "cursorright", "navright", "dpadright"],
    "OK": ["ok", "enter", "select", "okay", "center"],
    "BACK": ["return", "back", "exit"],
    "HOME": ["home", "smarthub", "menuhome", "hub"],
    "MENU": ["menu", "tools", "settings", "options", "setup"],
    "V+": ["volup", "volumeup", "vol+", "volume+", "volplus", "volumeplus"],
    "V-": ["voldown", "volumedown", "vol-", "volume-", "volminus", "volumeminus"],
    "MUTE": ["mute", "muting"],
    "C+": ["chup", "channelup", "ch+", "channel+", "chplus", "programup", "prup"],
    "C-": ["chdown", "channeldown", "ch-", "channel-", "chminus", "programdown", "prdown"],
    "LAST": ["last", "prevch", "prevchannel", "previouschannel", "recall", "flashback"],
    "REW": ["rewind", "rew", "rw", "fastbackward"],
    "PLAY": ["play", "playpause"],
    "PAUSE": ["pause"],
    "STOP": ["stop"],
    "FWD": ["forward", "fastforward", "ff", "fwd"],
}
for _n in range(10):
    NAMES[str(_n)] = [f"num{_n}", f"{_n}", f"digit{_n}", f"number{_n}", f"n{_n}"]

# the keys of the phone (typed characters; the d-pad, Enter, Esc and Ctrl are handled by the page itself): character -> a slot or the name of a button
KEYS = {"+": "V+", "=": "V+", "-": "V-", "_": "V-", "m": "MUTE", "c": "C+", "v": "C-", "h": "HOME", "s": "SRC", "i": "Info", "u": "MENU", "b": "BACK",
        "p": "PWR", "l": "LAST", " ": "OK", "\b": "BACK", "n": "page:123", "r": "page:more"}
for _n in range(10):
    KEYS[str(_n)] = str(_n)


def _key(name):
    """The normal form of a button name: lower case, without spaces, `_` and `-`; a `+` or `-` at the end stays (Vol+ and Vol- are different keys)."""
    n = name.strip().lower()
    tail = n[-1] if n and n[-1] in "+-" else ""
    return re.sub(r"[\s_\-+]+", "", n) + tail


def assign(buttons, forced=None):
    """(slots, rest): {slot: Button} and the buttons that no slot took. `forced`: {slot: exact button name} wins over the names."""
    by = {}
    for b in buttons:
        by.setdefault(_key(b.name), b)
    exact = {b.name: b for b in buttons}
    slots = {}
    for slot, names in NAMES.items():
        for n in names:
            if n in by:
                slots[slot] = by[n]
                break
    for slot, name in (forced or {}).items():
        if slot in SLOTS and name in exact:
            slots[slot] = exact[name]
    used = {id(b) for b in slots.values()}
    return slots, [b for b in buttons if id(b) not in used]


def load_forced(ir_path):
    """The sidecar file of a remote (`Name.layout.json` next to `Name.ir`), {} when there is none or it is broken."""
    try:
        with open(os.path.splitext(ir_path)[0] + ".layout.json", encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        return {}
    return {k: v for k, v in d.items() if isinstance(k, str) and isinstance(v, str)} if isinstance(d, dict) else {}


def load_keys(path=None):
    """The table of the keys of the phone: the defaults, changed by the file ~/.config/gothi/ir-keys.json ({"x": "Netflix", "q": null})."""
    table = dict(KEYS)
    path = path or os.path.join(os.path.expanduser("~"), ".config", "gothi", "ir-keys.json")
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        return table
    if isinstance(d, dict):
        for k, v in d.items():
            if isinstance(k, str) and len(k) == 1:
                if v is None:
                    table.pop(k, None)
                elif isinstance(v, str):
                    table[k] = v
    return table


def target_button(target, slots, buttons):
    """The Button for a slot or an exact button name (case and `_` do not matter), None when the remote has no such button."""
    if target in slots:
        return slots[target]
    want = _key(target)
    return next((b for b in buttons if _key(b.name) == want), None)
