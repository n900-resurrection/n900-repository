"""The page of one remote, drawn like a remote control (see docs/remote-layout.md): tiles for power, source, the arrows with OK, two rockers (volume,
channel), back / home / menu, a page of numbers and, on the tall screen, the media keys. What is not on a tile is in "More" (the list of buttons).

Keyboard slid out: no cursor, the keys of the phone are the keys of the remote (the d-pad, Enter, digits, a few letters; see slots.KEYS), the tile that was
sent flashes. Keyboard closed or any time with Settings > Tap the screen: a finger on a tile sends at once, a finger that stays on an arrow or a rocker
repeats. Power needs a long press (touch) or two presses (keyboard)."""
import time

from gothi import keys
from gothi.apps import Message
from gothi.ui import Menu, Scene

import ir_lib
import ir_lirc
import slots

HOLD_DELAY = 0.40          # seconds a finger stays on a key before it repeats
POWER_HOLD = 0.60          # seconds a finger stays on Power before it sends
POWER_ARMED = 3.0          # seconds in which the second press of the Power key of the keyboard counts
FLASH = 0.15               # seconds a tile that was sent is shown inverted
NOTE_SECONDS = 1.8
REPEATING = {"UP", "DOWN", "LEFT", "RIGHT", "V+", "V-", "C+", "C-", "REW", "FWD"}    # keys that repeat while held (a key that does something once, does not)
KEY_TARGETS = {keys.UP: "UP", keys.DOWN: "DOWN", keys.LEFT: "LEFT", keys.RIGHT: "RIGHT", keys.OK: "OK"}


def _thread(fn):
    import threading
    threading.Thread(target=fn, daemon=True).start()


class Buttons(Menu):
    """The buttons of one remote: OK (or Right) sends the selected one. The result is written on the title bar for a moment."""
    NOTE_SECONDS = 1.5
    tap_activates = True                                       # touch (gothi with Tap the screen): one tap sends the button

    def __init__(self, title, buttons, tx, spawn=_thread, clock=time.time):
        super().__init__(title[:20], [(b.name.replace("_", " "), None) for b in buttons])
        self.buttons, self.tx, self.spawn, self.clock = buttons, tx, spawn, clock
        self.busy = False
        self.note, self.note_until = "", 0.0
        self.sent = False
        self.rewarded = False

    def key(self, k, gothi):
        if k in (keys.OK, keys.RIGHT):
            self.fire()
        else:
            super().key(k, gothi)

    def fire(self):
        if self.busy or not self.buttons:
            return
        b = self.buttons[self.sel]
        self.busy, self.note, self.note_until = True, "sending", self.clock() + 30
        self.spawn(lambda: self._send(b))

    def _send(self, b):
        try:
            self.tx.send(ir_lib.encode(b))
            note, self.sent = ("sent: " + b.name.replace("_", " "))[:22], True
        except ir_lib.Unsupported as e:
            note = str(e)[:22]
        except ir_lirc.IrError as e:
            note = str(e)[:22]
        self.note, self.note_until, self.busy = note, self.clock() + self.NOTE_SECONDS, False

    def tick(self, now, gothi):
        if self.sent and not self.rewarded:
            self.rewarded = True
            gothi.deed("ir_send")

    def draw(self, c, gothi):
        super().draw(c, gothi)
        if self.note and self.clock() < self.note_until:          # the result takes the place of the title for a moment
            c.box(0, 0, c.w, 9, 0)
            c.text(2, 2, self.note)


class Tile:
    def __init__(self, action, x, y, w, h, label="", icon=None, strip=False):
        self.action, self.x, self.y, self.w, self.h, self.label, self.icon, self.strip = action, x, y, w, h, label, icon, strip

    def hit(self, px, py, slop=0):
        return self.x - slop <= px < self.x + self.w + slop and self.y - slop <= py < self.y + self.h + slop


def layout(page, h):
    """The tiles of a page for a screen of h rows. An action is a slot, `page:123`, `page:more`."""
    t = []
    if page == "123":
        ch = (h - 2) // 4
        for i, name in enumerate(["1", "2", "3", "4", "5", "6", "7", "8", "9", "LAST", "0", "MORE"]):
            action = {"MORE": "page:more", "LAST": "LAST"}.get(name, name)
            t.append(Tile(action, 1 + (i % 3) * 42, 1 + (i // 3) * ch, 41, ch - 1, name))
        return t
    tall = h >= 80
    uh, mh = (11, 15) if tall else (10, 14)
    top = 13
    t += [Tile("PWR", 0, 0, 26, 11, icon="power"), Tile("SRC", 102, 0, 26, 11, "SRC")]
    t += [Tile("UP", 26, top, 25, uh, icon="up"), Tile("LEFT", 2, top + uh + 1, 24, mh, icon="left"), Tile("OK", 26, top + uh + 1, 25, mh, "OK"),
          Tile("RIGHT", 51, top + uh + 1, 24, mh, icon="right"), Tile("DOWN", 26, top + uh + mh + 2, 25, uh, icon="down")]
    total = uh * 2 + mh + 2
    half = (total - 7) // 2
    for x, a, b, name, mid in ((79, "V+", "V-", "VOL", "MUTE"), (104, "C+", "C-", "CH", "LAST")):
        t += [Tile(a, x, top, 24, half + 1, icon="plus"), Tile(b, x, top + total - half - 1, 24, half + 1, icon="minus"),
              Tile(mid, x, top + half + 1, 24, total - 2 * (half + 1), name, strip=True)]
    by = top + total + 2
    for i, (a, name) in enumerate((("BACK", "BACK"), ("HOME", "HOME"), ("MENU", "MENU"), ("page:123", "123"))):
        t.append(Tile(a, i * 32, by, 31, 12, name))
    if tall:
        for i, (a, name) in enumerate((("REW", "<<"), ("PLAY", "PLAY"), ("STOP", "STOP"), ("FWD", ">>"))):
            t.append(Tile(a, i * 32, by + 13, 31, 12, name))
    return t


class Remote(Scene):
    title_back = False                      # the top row is Power and Source, not a title bar

    def __init__(self, name, buttons, tx, forced=None, keymap=None, spawn=_thread, clock=time.time):
        self.name, self.buttons, self.tx, self.spawn, self.clock = name, buttons, tx, spawn, clock
        self.slots, self.rest = slots.assign(buttons, forced)
        self.keymap = keymap if keymap is not None else slots.load_keys()
        self.page = "main"
        self.text_input = False
        self.queue, self.running = [], False
        self.flash = {}                     # action -> time until which the tile is shown pressed
        self.note, self.note_until = "", 0.0
        self.held = None                    # the finger that is down on a tile: (tile, time down, time of the next repeat)
        self.power_since = None
        self.power_armed = 0.0
        self.next_repeat = 0.0
        self.toggle = 0                     # RC5 toggle bit: flips with every new press
        self.play_next = "PLAY"
        self.sent = False
        self.rewarded = False
        self.tiles_cache = {}

    # ---- what is sent -------------------------------------------------------
    def _button(self, action):
        if action == "PLAY" and self.play_next == "PAUSE" and "PAUSE" in self.slots and "PLAY" in self.slots:
            return self.slots["PAUSE"]
        if action == "PLAY" and "PLAY" not in self.slots and "PAUSE" in self.slots:
            return self.slots["PAUSE"]
        return slots.target_button(action, self.slots, self.buttons)

    def say(self, text):
        self.note, self.note_until = text[:22], self.clock() + NOTE_SECONDS

    def send(self, action, repeat=False):
        """Queue the button of a slot (or a button name); `repeat`: a held key, the short repeat of the protocol. Returns False when there is no button."""
        b = self._button(action)
        if b is None:
            self.say("no " + action.lower().replace("_", " "))
            return False
        now = self.clock()
        if repeat:
            if now < self.next_repeat:
                return True                                          # the keyboard repeats faster than a remote does
            self.next_repeat = now + ir_lib.hold_period(b)
        else:
            self.next_repeat = now
        self.flash[action] = now + FLASH
        if not repeat:
            self.toggle ^= 1
            if action == "PLAY" and "PAUSE" in self.slots and "PLAY" in self.slots:
                self.play_next = "PAUSE" if self.play_next == "PLAY" else "PLAY"
        if not repeat or not self.queue:
            self.queue.append((b, repeat, self.toggle, action))
            self.queue = self.queue[-3:]                       # a long queue would keep sending after the finger is gone
        if not self.running:
            self.running = True
            self.spawn(self._work)
        return True

    def _work(self):
        while True:
            if not self.queue:
                self.running = False
                return
            b, repeat, toggle, action = self.queue.pop(0)
            try:
                self.tx.send(ir_lib.hold_plan(b, toggle) if repeat else ir_lib.encode(b, toggle))
                self.sent = True
            except (ir_lib.Unsupported, ir_lirc.IrError) as e:
                self.note, self.note_until = str(e)[:22], self.clock() + NOTE_SECONDS
                self.flash[action] = self.clock() + 0.6

    # ---- keys of the phone --------------------------------------------------
    def key(self, k, gothi):
        if k in KEY_TARGETS:
            if gothi.key_repeat and KEY_TARGETS[k] not in REPEATING:
                return                                               # holding OK does not press it again and again
            self.send(KEY_TARGETS[k], repeat=gothi.key_repeat)
        elif k == keys.BACK:                                       # Esc and Ctrl leave: the number page goes back to the main one first
            if self.page != "main":
                self.page = "main"
            else:
                gothi.pop()

    def on_text(self, s, gothi):
        for ch in s:
            target = self.keymap.get(ch)
            if not target:
                continue
            if target.startswith("page:"):
                if not gothi.key_repeat:
                    self.go(target[5:], gothi)
            elif target == "PWR":
                self.power_key(gothi.key_repeat)
            elif gothi.key_repeat and target not in REPEATING:
                continue
            else:
                self.send(target, repeat=gothi.key_repeat)

    def power_key(self, repeat):
        now = self.clock()
        if repeat:
            return
        if now < self.power_armed:
            self.power_armed = 0.0
            self.send("PWR")
        else:
            self.power_armed = now + POWER_ARMED
            self.say("press P again: power")

    def go(self, page, gothi):
        if page == "more":
            rest = self.rest or self.buttons
            gothi.push(Buttons("More", rest, self.tx))               # the list of buttons that the page does not have
        elif page == "123":
            self.page = "main" if self.page == "123" else "123"

    # ---- touch ---------------------------------------------------------------
    def tiles(self, h):
        key = (self.page, h)
        if key not in self.tiles_cache:
            self.tiles_cache[key] = layout(self.page, h)
        return self.tiles_cache[key]

    def tile_at(self, x, y, h):
        tiles = self.tiles(h)
        return next((t for t in tiles if t.hit(x, y)), None) or next((t for t in tiles if t.hit(x, y, 1)), None)

    def on_down(self, x, y, gothi):
        t = self.tile_at(x, y, gothi.h)
        if t is None:
            return
        now = self.clock()
        if t.action.startswith("page:"):
            self.go(t.action[5:], gothi)
        elif t.action == "PWR":
            self.power_since = now                                   # sent when the finger stays long enough (tick)
            self.held = (t, now, None)
        else:
            self.send(t.action)
            self.held = (t, now, now + HOLD_DELAY if t.action in REPEATING else None)

    def on_up(self, x, y, gothi):
        if self.power_since is not None:
            self.say("hold to power")
        self.held, self.power_since = None, None

    def on_tap(self, x, y, gothi):
        pass                                                         # the work is done at the touch down

    def tick(self, now, gothi):
        self.text_input = gothi.mode == "keyboard" and self.page != "123"      # SDL text input only where the keyboard is
        if self.held:
            t, since, nxt = self.held
            if self.power_since is not None and now - self.power_since >= POWER_HOLD:
                self.power_since = None
                self.send("PWR")
            elif nxt is not None and now >= nxt:
                self.send(t.action, repeat=True)                     # send() keeps the pace of the protocol
        if self.sent and not self.rewarded:
            self.rewarded = True
            gothi.deed("ir_send")

    # ---- drawing -------------------------------------------------------------
    def draw(self, c, gothi):
        now = self.clock()
        for t in self.tiles(c.h):
            inv = self.flash.get(t.action, 0) > now or (self.held is not None and self.held[0] is t and t.action != "PWR")
            self._tile(c, t, inv, dim=not self._enabled(t.action))
        if self.power_since is not None and self.held:                  # the long press fills the Power tile
            t = self.held[0]
            frac = min(1.0, (now - self.power_since) / POWER_HOLD)
            c.box(t.x, t.y, int(t.w * frac), t.h)
        if self.page == "main":
            shown = self.note if self.note and now < self.note_until else self.name
            c.box(27, 0, 74, 10, 0)
            c.text(64 - c.text_width(shown[:18]) // 2, 3, shown[:18])

    def _enabled(self, action):
        if action.startswith("page:"):
            return True
        if action == "PLAY":
            return "PLAY" in self.slots or "PAUSE" in self.slots
        return action in self.slots or slots.target_button(action, self.slots, self.buttons) is not None

    @staticmethod
    def _tile(c, t, inv, dim=False):
        x, y, w, h = t.x, t.y, t.w, t.h
        if t.strip:                                                     # the name between the + and - of a rocker; it is a key too (Mute, Last)
            ink = 0 if inv else 1
            if inv:
                c.box(x, y, w, h)
            c.text(x + (w - c.text_width(t.label)) // 2, y + (h - 5) // 2, t.label, v=ink)
            return
        if inv:
            c.box(x, y, w, h)
            for px, py in ((x, y), (x + w - 1, y), (x, y + h - 1), (x + w - 1, y + h - 1)):
                c.pixel(px, py, 0)
        elif dim:                                                       # a button that this remote does not have: a dotted frame
            for i in range(1, w - 1, 2):
                c.pixel(x + i, y)
                c.pixel(x + i, y + h - 1)
            for j in range(1, h - 1, 2):
                c.pixel(x, y + j)
                c.pixel(x + w - 1, y + j)
        else:
            c.hline(x + 1, y, w - 2)
            c.hline(x + 1, y + h - 1, w - 2)
            c.vline(x, y + 1, h - 2)
            c.vline(x + w - 1, y + 1, h - 2)
        ink = 0 if inv else 1
        cx, cy = x + w // 2, y + h // 2
        i = t.icon
        if i == "up":
            for n in range(4):
                c.hline(cx - n, cy - 2 + n, 2 * n + 1, ink)
        elif i == "down":
            for n in range(4):
                c.hline(cx - n, cy + 1 - n, 2 * n + 1, ink)
        elif i == "left":
            for n in range(4):
                c.vline(cx - 2 + n, cy - n, 2 * n + 1, ink)
        elif i == "right":
            for n in range(4):
                c.vline(cx + 1 - n, cy - n, 2 * n + 1, ink)
        elif i == "power":
            c.frame(cx - 3, cy - 2, 7, 6, ink)
            c.box(cx - 1, cy - 5, 3, 4, 1 if inv else 0)
            c.vline(cx, cy - 5, 4, ink)
        elif i == "plus":
            c.hline(cx - 2, cy, 5, ink)
            c.vline(cx, cy - 2, 5, ink)
        elif i == "minus":
            c.hline(cx - 2, cy, 5, ink)
        elif t.label:
            c.text(cx - c.text_width(t.label) // 2, cy - 2, t.label, v=ink)
