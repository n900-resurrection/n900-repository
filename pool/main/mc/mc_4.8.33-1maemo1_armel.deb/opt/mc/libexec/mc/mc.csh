alias mc 'source /opt/mc/libexec/mc/mc-wrapper.csh'
