(setf difficulty 'easy)
