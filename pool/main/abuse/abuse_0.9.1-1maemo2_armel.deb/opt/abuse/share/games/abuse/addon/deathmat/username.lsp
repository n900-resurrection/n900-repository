(setq username "EvilWumpus")
